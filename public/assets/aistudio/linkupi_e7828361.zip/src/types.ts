/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PaymentStatus = 'pending' | 'verified' | 'rejected';

export interface BusinessSettings {
  accountType?: 'business' | 'individual';
  businessName: string;
  address?: string;
  upiId: string;
  upiQrImage: string; // Base64 or placeholder URL
  whatsappNumber: string;
  supportEmail: string;
  logoImage?: string;       // Base64 logo upload
  signatureImage?: string;  // Base64 signature upload
}

export interface Payment {
  id: string;
  date: string; // ISO String
  customerName: string;
  mobile: string;
  email?: string;
  amount: number;
  utrNumber: string;
  screenshot?: string; // Base64 or mock image url
  status: PaymentStatus;
  adminNote?: string;
  statusChangedAt?: string;
  receiptNo?: string;
}

export interface Customer {
  id: string;
  name: string;
  mobile: string;
  email?: string;
  totalPaid: number;
  lastPaymentDate: string;
  status: PaymentStatus;
  subscriptionType?: 'monthly' | 'yearly' | 'one-time' | 'custom' | 'none';
  renewalAmount?: number;
  remarks?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  details: string;
  adminUser: string;
}

export interface AdminUser {
  username: string;
  role: 'admin' | 'merchant';
  isLoggedIn: boolean;
}

export interface ShortUrl {
  id: string;
  originalUrl: string;
  token: string;
  created: string;
  amount: string;
  remarks: string;
  clicks: number;
}

