import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta as any).env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = (import.meta as any).env.VITE_SUPABASE_ANON_KEY || '';

// Verify configuration variables are loaded and are non-empty
export const isSupabaseConfigured = !!(
  supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl.trim() !== '' && 
  supabaseAnonKey.trim() !== '' &&
  !supabaseUrl.includes('YOUR_SUPABASE')
);

// Fallback dummy credentials to prevent the client from throwing synchronous launch crashes
const fallbackUrl = 'https://your-supabase-project.supabase.co';
const fallbackKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.dummy-anon-key-to-avoid-startup-crash-until-user-secrets-are-configured';

export const supabase = createClient(
  isSupabaseConfigured ? supabaseUrl.trim() : fallbackUrl,
  isSupabaseConfigured ? supabaseAnonKey.trim() : fallbackKey
);

/**
 * Executes a light, schema-independent connection handshake.
 * This checks authentication metadata to verify both network ingress routes and API keys.
 */
export async function testSupabaseConnection(): Promise<{ success: boolean; message: string; details?: any }> {
  if (!isSupabaseConfigured) {
    return {
      success: false,
      message: 'Supabase configuration is missing. Please define VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment/secrets panel.'
    };
  }

  try {
    // Attempt authentication session check (completely table-agnostic, works on brand new empty Supabase projects)
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      return {
        success: false,
        message: `API Key/Credentials error: ${error.message}`,
        details: error
      };
    }

    return {
      success: true,
      message: 'Supabase Connected Successfully!'
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Could not establish connection to the Supabase endpoint. Please verify the URL.',
      details: err
    };
  }
}
