/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Suffix mappings for UPI handles to save space
const UPI_SUFFIXES: { [key: string]: string } = {
  '@oksbi': '_1',
  '@okaxis': '_2',
  '@okicici': '_3',
  '@okhdfcbank': '_4',
  '@ybl': '_5',
  '@paytm': '_6',
  '@axl': '_7',
  '@ibl': '_8',
  '@barodampay': '_9',
  '@upi': '_0'
};

const REVERSE_UPI_SUFFIXES: { [key: string]: string } = {
  '_1': '@oksbi',
  '_2': '@okaxis',
  '_3': '@okicici',
  '_4': '@okhdfcbank',
  '_5': '@ybl',
  '_6': '@paytm',
  '_7': '@axl',
  '_8': '@ibl',
  '_9': '@barodampay',
  '_0': '@upi'
};

/**
 * Encodes billing parameters into a single short URL-safe Base64 token.
 * Struct: amount~remarks~upiId~businessName~phone
 */
export function encodePayload(a: string, r: string, u: string, n: string, ph: string): string {
  try {
    const rawStr = [a.trim(), r.trim(), u.trim(), n.trim(), ph.trim()].join('~');
    // Unicode-safe Base64 encoding
    const utf8Str = unescape(encodeURIComponent(rawStr));
    const base64 = btoa(utf8Str);
    // Make URL-safe (replace +, / and remove padding =)
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  } catch (e) {
    console.error('Error encoding short payment payload:', e);
    return '';
  }
}

/**
 * Decodes a URL-safe Base64 token back into the payment parameters.
 */
export function decodePayload(token: string): { a: string; r: string; u: string; n: string; ph: string } | null {
  if (!token) return null;
  try {
    // Restore standard Base64 characters and padding
    let base64 = token.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
      base64 += '=';
    }
    // Unicode-safe Base64 decoding
    const binaryStr = atob(base64);
    const rawStr = decodeURIComponent(escape(binaryStr));
    const parts = rawStr.split('~');

    if (parts.length >= 5) {
      return {
        a: parts[0] || '',
        r: parts[1] || '',
        u: parts[2] || '',
        n: parts[3] || '',
        ph: parts[4] || ''
      };
    }
  } catch (e) {
    console.error('Error decoding short payment payload:', e);
  }
  return null;
}

/**
 * High-compression URL encoder for UPI/Fintech payloads.
 * Strips common domain suffixes, utilizes short delimiters, and outputs standard URL-safe Base64.
 */
export function compressPayload(a: string, r: string, u: string, n: string, ph: string): string {
  try {
    // Shorten UPI VPA if possible
    let compactUpi = u.trim();
    for (const [suffix, code] of Object.entries(UPI_SUFFIXES)) {
      if (compactUpi.toLowerCase().endsWith(suffix)) {
        compactUpi = compactUpi.slice(0, -suffix.length) + code;
        break;
      }
    }
    // Construct a collapsed raw string with tiny vertical separator
    const rawStr = [a.trim(), r.trim(), compactUpi, n.trim(), ph.trim()].join('|');
    const utf8Str = unescape(encodeURIComponent(rawStr));
    const base64 = btoa(utf8Str);
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  } catch (e) {
    console.error('Error compressing payload:', e);
    return encodePayload(a, r, u, n, ph); // Fallback
  }
}

/**
 * Decompresses the high-compression payment token back to standard fields.
 */
export function decompressPayload(token: string): { a: string; r: string; u: string; n: string; ph: string } | null {
  if (!token) return null;
  try {
    let base64 = token.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
      base64 += '=';
    }
    const binaryStr = atob(base64);
    const rawStr = decodeURIComponent(escape(binaryStr));
    
    // Auto-detect high compression or legacy separators
    const delimiter = rawStr.includes('|') ? '|' : '~';
    const parts = rawStr.split(delimiter);
    if (parts.length >= 5) {
      let upi = parts[2] || '';
      // Restore common UPI domain suffix if matched
      for (const [code, suffix] of Object.entries(REVERSE_UPI_SUFFIXES)) {
        if (upi.toLowerCase().endsWith(code)) {
          upi = upi.slice(0, -code.length) + suffix;
          break;
        }
      }
      return {
        a: parts[0] || '',
        r: parts[1] || '',
        u: upi,
        n: parts[3] || '',
        ph: parts[4] || ''
      };
    }
  } catch (e) {
    console.error('Error decompressing payload:', e);
  }
  return decodePayload(token); // Fallback to standard
}

