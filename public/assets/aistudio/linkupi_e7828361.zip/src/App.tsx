/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import CustomerPayment from './components/CustomerPayment';
import PaymentStatus from './components/PaymentStatus';
import FintechEffectsWrapper from './components/FintechEffectsWrapper';
import { db } from './services/db';
import { BusinessSettings } from './types';
import { decodePayload, decompressPayload } from './utils/url';

export default function App() {
  const [route, setRoute] = useState<'landing' | 'payment' | 'status'>('landing');
  
  // Custom business settings sync state
  const [settings, setSettings] = useState<BusinessSettings>(() => db.getSettings());

  // Cached state to pass query payload to tracking directly from success page
  const [submittedMobile, setSubmittedMobile] = useState('');
  const [submittedUtr, setSubmittedUtr] = useState('');

  // Prefilled states from share link
  const [prefilledAmount, setPrefilledAmount] = useState<number | undefined>(undefined);
  const [prefilledRemarks, setPrefilledRemarks] = useState<string>('');
  const [prefilledPhone, setPrefilledPhone] = useState<string>('');
  const [customUpi, setCustomUpi] = useState<string | undefined>(undefined);
  const [customName, setCustomName] = useState<string | undefined>(undefined);

  // Handle settings update callback
  const handleSettingsUpdated = (newSettings: BusinessSettings) => {
    setSettings(newSettings);
  };

  // Sync route on direct hash load or state
  useEffect(() => {
    // If we have custom parameters, we can parse them, but standard state router is best.
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [route]);

  // Read share-link URL queries on boot
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const dParam = params.get('d');
    const sParam = params.get('s') || params.get('sh');
    
    let amt = params.get('a') || params.get('amount');
    let rem = params.get('r') || params.get('remarks');
    let ph = params.get('ph') || params.get('phone');
    let upiParam = params.get('u') || params.get('upi');
    let nameParam = params.get('n') || params.get('name');
    let payParam = params.get('p') || params.get('pay');

    if (dParam) {
      const decoded = decodePayload(dParam) || decompressPayload(dParam);
      if (decoded) {
        amt = decoded.a || amt;
        rem = decoded.r || rem;
        upiParam = decoded.u || upiParam;
        nameParam = decoded.n || nameParam;
        ph = decoded.ph || ph;
        payParam = '1';
      }
    } else if (sParam) {
      // 1. Check if matches registered short URL map (for click statistics tracking)
      const registered = db.findShortUrlById(sParam);
      if (registered) {
        db.incrementShortUrlClicks(sParam);
        const decoded = decompressPayload(registered.token);
        if (decoded) {
          amt = decoded.a || amt;
          rem = decoded.r || rem;
          upiParam = decoded.u || upiParam;
          nameParam = decoded.n || nameParam;
          ph = decoded.ph || ph;
          payParam = '1';
        }
      } else {
        // 2. Direct decompressed token fallback so links survive across devices without local DB synchronization
        const decoded = decompressPayload(sParam);
        if (decoded) {
          amt = decoded.a || amt;
          rem = decoded.r || rem;
          upiParam = decoded.u || upiParam;
          nameParam = decoded.n || nameParam;
          ph = decoded.ph || ph;
          payParam = '1';
        }
      }
    }

    if (upiParam) {
      setCustomUpi(upiParam);
    }
    if (nameParam) {
      setCustomName(nameParam);
    }

    if (amt || rem || ph || upiParam || payParam === 'true' || payParam === '1') {
      if (amt) {
        const val = parseFloat(amt);
        if (!isNaN(val) && val > 0) {
          setPrefilledAmount(val);
        }
      }
      if (rem) {
        setPrefilledRemarks(rem);
      }
      if (ph) {
        setPrefilledPhone(ph);
      }
      setRoute('payment');
    }
  }, []);

  // Compute live active settings (reconciling loaded parameters instantly for unauthenticated checkouts)
  const activeSettings: BusinessSettings = {
    ...settings,
    upiId: customUpi || settings.upiId,
    businessName: customName || settings.businessName,
  };

  return (
    <div id="zuelpay-root" className="min-h-screen bg-slate-50 font-sans tracking-tight antialiased selection:bg-blue-500 selection:text-white">
      <FintechEffectsWrapper route={route}>
        {route === 'landing' && (
          <LandingPage 
            settings={activeSettings} 
            setRoute={setRoute} 
            onProfileUpdated={handleSettingsUpdated}
          />
        )}

        {route === 'payment' && (
          <CustomerPayment 
            settings={activeSettings} 
            setRoute={setRoute} 
            setSubmittedMobile={setSubmittedMobile}
            setSubmittedUtr={setSubmittedUtr}
            prefilledAmount={prefilledAmount}
            prefilledRemarks={prefilledRemarks}
            prefilledPhone={prefilledPhone}
          />
        )}

        {route === 'status' && (
          <PaymentStatus 
            initialMobile={submittedMobile}
            initialUtr={submittedUtr}
            onBackToLanding={() => {
              setSubmittedMobile('');
              setSubmittedUtr('');
              setRoute('landing');
            }}
            whatsappNumber={settings.whatsappNumber}
          />
        )}
      </FintechEffectsWrapper>
    </div>
  );
}

