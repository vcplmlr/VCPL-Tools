/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  QrCode, 
  ArrowRight, 
  Layers, 
  CheckCircle, 
  UserCheck, 
  FileText, 
  Smartphone, 
  MessageCircle,
  Mail,
  Copy,
  Check,
  Share2,
  Sparkles,
  ArrowUpRight,
  Sliders,
  Save,
  Activity,
  User,
  Zap,
  TrendingUp,
  Search,
  Lock,
  RefreshCw,
  Globe,
  DollarSign,
  Heart,
  ChevronRight,
  Star,
  X,
  Link2,
  Instagram
} from 'lucide-react';
import { BusinessSettings } from '../types';
import { db } from '../services/db';
import QRCodeGenerator from './QRCodeGenerator';
import { encodePayload, compressPayload } from '../utils/url';
import { TiltCard, MagneticButton } from './FintechEffectsWrapper';

interface LandingPageProps {
  settings: BusinessSettings;
  setRoute: (route: 'landing' | 'payment' | 'status') => void;
  onProfileUpdated?: (settings: BusinessSettings) => void;
}

export default function LandingPage({ settings, setRoute, onProfileUpdated }: LandingPageProps) {
  // Profile settings states (pre-filled with saved DB coordinates)
  const [profileName, setProfileName] = useState(settings.businessName || '');
  const [profileUpi, setProfileUpi] = useState(settings.upiId || '');
  const [profileWhatsApp, setProfileWhatsApp] = useState(settings.whatsappNumber || '');
  const [profileEmail, setProfileEmail] = useState(settings.supportEmail || '');

  // Live calculator billing parameters - Empty by default as requested
  const [payAmount, setPayAmount] = useState('');
  const [payNote, setPayNote] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');

  // Interface Feedbacks
  const [copiedLink, setCopiedLink] = useState(false);
  const [profileSaved, setProfileSaved] = useState(false);
  const [validationError, setValidationError] = useState('');

  // Active Bitly-Style Link Shortener State
  const [shortenedUrl, setShortenedUrl] = useState('');
  const [isShortening, setIsShortening] = useState(false);
  const [copiedShort, setCopiedShort] = useState(false);
  const [shortHistory, setShortHistory] = useState(() => db.getShortUrls());
  const [toastMessage, setToastMessage] = useState('');
  const [activePolicyModal, setActivePolicyModal] = useState<'terms' | 'privacy' | 'refund' | null>(null);

  // Interactive Live Ledger Sandbox Simulator States
  const [simStep, setSimStep] = useState<'idle' | 'checkout' | 'paid' | 'verified'>('idle');
  const [simAmount, setSimAmount] = useState('1500');
  const [simUtr, setSimUtr] = useState('328904729104');
  const [simRemarks, setSimRemarks] = useState('Yoga Studio Membership');
  const [simCopied, setSimCopied] = useState(false);

  // Settle live values from typing coordinates, falling back instantly to settings if inputs are cleared
  const activeUpi = profileUpi.trim() || settings.upiId;
  const activeName = profileName.trim() || settings.businessName;

  // Compile deep live customer mobile gateway link with a collapsed short query token (uses high compression)
  const shortData = compressPayload(payAmount, payNote, activeUpi, activeName, customerMobile);
  // Get or dynamically create a short URL record so the checkout URL is ALWAYS a short bitly-style ID
  const activeShortRecord = db.getOrCreateShortUrl(payAmount, payNote, activeUpi, activeName, customerMobile, shortData);
  const liveCheckoutUrl = `${window.location.origin}/?s=${activeShortRecord.id}`;

  // Testimonials active carousel handler
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const testimonials = [
    {
      quote: "ZuelPay bypassed our high PG payment gateway commission fees entirely. We verify ₹5 Lakhs worth of training fees monthly using simple manual UTR matching - 0% fee is incredible!",
      author: "Koushik Sharma",
      role: "Founder, Apex Fitness Arena",
      location: "Bengaluru, India"
    },
    {
      quote: "The interface compiles short pay links beautifully. Sending invoices directly to clients via WhatsApp gets us settled in minutes. Truly minimalist and highly functional.",
      author: "Aditi Roy",
      role: "Freelance Creative Lead",
      location: "Mumbai, India"
    },
    {
      quote: "No subscription fees, no complicated APIs. Our reception simply matches the submitted customer UTR receipt IDs on our private admin dashboard. Solves our collection hassles.",
      author: "Gautam Malhotra",
      role: "Operational Manager, Gym Settle Solutions",
      location: "New Delhi, India"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  // Persist Profile Coordinate Settings to Local Database
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');
    setProfileSaved(false);

    if (!profileUpi.trim()) {
      setValidationError('Please specify a valid active VPA UPI Address.');
      return;
    }

    if (!profileUpi.includes('@')) {
      setValidationError('UPI handle must be a valid VPA address containing "@" (e.g., name@okbank).');
      return;
    }

    try {
      const updated = db.updateSettings({
        businessName: profileName.trim() || 'Authorized Payee',
        upiId: profileUpi.trim(),
        whatsappNumber: profileWhatsApp.trim(),
        supportEmail: profileEmail.trim(),
        accountType: 'business'
      });

      if (onProfileUpdated) {
        onProfileUpdated(updated);
      }

      // Show immediate elegant feedback
      setProfileSaved(true);
      setTimeout(() => setProfileSaved(false), 3000);
    } catch (err: any) {
      setValidationError('Error saving profile settings: ' + err.message);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(liveCheckoutUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleWhatsAppShare = () => {
    const amountVal = payAmount ? parseFloat(payAmount) : 0;
    const notesStr = payNote ? `"${payNote}"` : 'Payment';
    const payeeStr = activeName || 'Authorized Payee';
    const targetUrl = shortenedUrl || liveCheckoutUrl;

    const textMessage = `💸 *Payment Request from ${payeeStr}*

💵 *Requested Amount:* ${amountVal > 0 ? `₹${amountVal.toFixed(2)}` : 'Specify variable amount'}
📌 *Statement Note:* ${notesStr}

👉 *Tap link to pay instantly:*
${targetUrl}

_Thank you!_`;

    let cleanPhone = customerMobile.replace(/[^0-9]/g, '');
    if (cleanPhone.length === 10) {
      cleanPhone = '91' + cleanPhone; // Auto-assume Indian dial code if length is exactly 10
    }

    const waUrl = cleanPhone 
      ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(textMessage)}`
      : `https://wa.me/?text=${encodeURIComponent(textMessage)}`;

    window.open(waUrl, '_blank');
  };

  const handleGenerateShortLink = () => {
    setValidationError('');
    
    if (!payAmount && !payNote && !customerMobile) {
      setValidationError('Please input some payment parameters (Amount, Purpose, or Mobile) first to generate a shortened link.');
      return;
    }

    if (!activeUpi) {
      setValidationError('Please specify your bank UPI routing details in Step A first.');
      return;
    }

    try {
      setIsShortening(true);
      const liveToken = compressPayload(payAmount, payNote, activeUpi, activeName, customerMobile);
      const shortRecord = db.createShortUrl(payAmount, payNote, activeUpi, activeName, customerMobile, liveToken);
      
      const generatedLink = `${window.location.origin}/?s=${shortRecord.id}`;
      setShortenedUrl(generatedLink);
      setShortHistory(db.getShortUrls());
      
      setToastMessage(`⚡ Short link generated: ${shortRecord.id}`);
      setTimeout(() => setToastMessage(''), 4000);
    } catch (err: any) {
      setValidationError('Error generating short link: ' + err.message);
    } finally {
      setIsShortening(false);
    }
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="landing-page" className="min-h-screen bg-[#090D1A] text-slate-100 selection:bg-blue-600 selection:text-white flex flex-col justify-between font-sans">
      
      {/* 1. Navbar: Glassmorphism Fintech Style Sticky Header */}
      <header className="bg-[#090D1A]/85 border-b border-slate-800/60 sticky top-0 z-50 backdrop-blur-md shadow-lg shadow-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Main Title Identity Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setRoute('landing')}>
            <div className="w-10 h-10 bg-gradient-to-tr from-blue-600 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20 border border-blue-400/30">
              <span className="text-white font-extrabold text-lg select-none font-sora">ZP</span>
            </div>
            <div>
              <span className="font-extrabold text-lg tracking-tight text-white font-sora">Zuel<span className="text-blue-500">Pay</span></span>
              <span className="block text-[8px] font-mono tracking-widest uppercase text-emerald-400 font-black leading-none">ZERO-FEE UPI GATEWAY</span>
            </div>
          </div>

          {/* Center SaaS Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-xs font-semibold uppercase tracking-wider text-slate-350">
            <button onClick={() => scrollToSection('features-section')} className="hover:text-blue-500 transition-colors cursor-pointer">Features</button>
            <button onClick={() => scrollToSection('how-it-works')} className="hover:text-blue-500 transition-colors cursor-pointer">How It Works</button>
            <button onClick={() => scrollToSection('interactive-workspace')} className="hover:text-blue-500 font-extrabold text-blue-400 hover:text-white transition-colors cursor-pointer flex items-center gap-1 bg-blue-500/10 px-2.5 py-1 rounded-lg border border-blue-500/20">
              <Sparkles className="w-3.5 h-3.5" /> Workspace Generator
            </button>
            <button onClick={() => scrollToSection('testimonials-section')} className="hover:text-blue-500 transition-colors cursor-pointer">Reviews</button>
          </nav>

          {/* Right Area Action Buttons */}
          <div className="flex items-center gap-2.5">
            <button 
              onClick={() => setRoute('status')} 
              className="px-4 py-2 bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition-all border border-slate-800 hover:border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Search className="w-3.5 h-3.5 text-blue-400" />
              <span>Track Payment</span>
            </button>
            <button 
              onClick={() => setRoute('payment')} 
              className="px-4.5 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-550 hover:to-blue-650 text-white rounded-xl text-xs font-extrabold uppercase tracking-wide transition-all duration-300 shadow-md shadow-blue-500/15 border border-blue-400/20 hover:scale-[1.02] active:scale-[0.98] flex items-center gap-1.5 cursor-pointer"
            >
              <span>Test Pay Screen</span>
              <ArrowRight className="w-3.5 h-3.5 text-blue-200" />
            </button>
          </div>

        </div>
      </header>

      {/* Main Container Page Wrap */}
      <div className="flex-grow">
        
        {/* 2. Hero Section: Premium Fintech Presentation with Floating Badges */}
        <section className="relative overflow-hidden pt-12 pb-20 md:py-28 lg:py-36 border-b border-slate-900">
          
          {/* Ambient space background glow layers */}
          <div className="absolute top-1/4 left-1/3 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none select-none"></div>
          <div className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] bg-indigo-600/5 rounded-full blur-[120px] pointer-events-none select-none"></div>
          
          {/* Subtle grid mesh watermark background */}
          <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px] opacity-15 pointer-events-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
              
              {/* Hero Left Content */}
              <div className="lg:col-span-7 text-left space-y-6">
                
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 text-blue-400 text-[10px] font-extrabold uppercase tracking-widest rounded-full border border-blue-500/20">
                  <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping"></span>
                  100% In-Browser UPI Utility · Zero Servers · Zero Fees
                </div>

                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1] font-sora">
                  Generate UPI QR Codes.<br />
                  <span className="bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">Direct to Your Bank.</span><br />
                  100% In Your Browser.
                </h1>

                <p className="max-w-2xl text-slate-400 text-sm leading-relaxed font-sans">
                  Create custom UPI payment QR codes and shareable pay links directly on your device. Zero commission, no merchant accounts or backend servers required, with local browser-only data storage.
                </p>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
                  <button
                    onClick={() => scrollToSection('interactive-workspace')}
                    className="px-6 py-4 bg-blue-600 hover:bg-blue-550 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all duration-300 shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.01]"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>Create UPI QR Code</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setRoute('status')}
                    className="px-6 py-4 bg-slate-900 hover:bg-slate-850 text-slate-200 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Search className="w-4 h-4 text-blue-400" />
                    <span>Track / Check Payment</span>
                  </button>
                </div>

                {/* Trust mini-badges */}
                <div className="pt-6 border-t border-slate-900 flex flex-wrap gap-x-6 gap-y-2.5 text-[11px] text-slate-500">
                  <span className="flex items-center gap-1.5 font-medium"><ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> 0% Transaction Fees</span>
                  <span className="flex items-center gap-1.5 font-medium"><Sparkles className="w-3.5 h-3.5 text-blue-500" /> Direct-to-Bank Ledgers</span>
                  <span className="flex items-center gap-1.5 font-medium"><Lock className="w-3.5 h-3.5 text-indigo-500" /> Sandboxed Local Security</span>
                </div>

              </div>

              {/* Hero Right Visuals: Interactive CSS Fintech Mockup & Floating Badges */}
              <div className="lg:col-span-5 relative mt-8 lg:mt-0 flex items-center justify-center">
                
                {/* Floating elements animation container */}
                <div className="relative w-full max-w-sm aspect-square bg-[#0E1528] border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col justify-between">
                  
                  {/* Glowing core logo background */}
                  <div className="absolute -inset-0.5 bg-gradient-to-tr from-blue-600 to-indigo-500 rounded-3xl opacity-10 blur-xl"></div>

                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      <span className="text-[9px] font-black text-slate-400 font-mono tracking-wider uppercase">Live Ledger Stream</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">zuelpay.net</span>
                  </div>

                  {/* Simulated Telemetry Feed */}
                  <div className="my-6 space-y-3 flex-grow">
                    
                    <div className="p-3.5 bg-[#090D1A] border border-slate-800/80 rounded-2xl flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20 text-emerald-400">
                          ✓
                        </div>
                        <div>
                          <p className="text-[10.5px] font-bold text-white leading-tight">Payment Verified Successfully</p>
                          <p className="text-[8.5px] text-slate-500 font-mono tracking-tight mt-0.5">UTR Reference #928374829104</p>
                        </div>
                      </div>
                      <span className="text-[11px] font-black text-emerald-400 font-mono">₹1,500.00</span>
                    </div>

                    <div className="p-3.5 bg-[#090D1A] border border-slate-800/80 rounded-2xl flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-yellow-500/15 flex items-center justify-center border border-yellow-500/30 text-yellow-400 font-bold">
                          ●
                        </div>
                        <div>
                          <p className="text-[10.5px] font-bold text-white leading-tight">Pending UTR Match Settle</p>
                          <p className="text-[8.5px] text-slate-500 font-mono tracking-tight mt-0.5">Mobile *9956 submitted manual claim</p>
                        </div>
                      </div>
                      <span className="text-[11px] font-black text-yellow-400 font-mono">₹500.00</span>
                    </div>

                    <div className="p-3.5 bg-[#090D1A] border border-slate-800/80 rounded-2xl flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center border border-blue-500/20 text-blue-400">
                          ⚡
                        </div>
                        <div>
                          <p className="text-[10.5px] font-bold text-white leading-tight">QR Generated for Customer</p>
                          <p className="text-[8.5px] text-slate-500 font-mono tracking-tight mt-0.5">Registered amount lock activated</p>
                        </div>
                      </div>
                      <span className="text-[11px] font-black text-blue-400 font-mono">₹12,400.00</span>
                    </div>

                  </div>

                  <div className="bg-[#090D1A] p-3 border border-slate-800/50 rounded-xl text-center">
                    <span className="text-[9px] text-slate-500 font-mono block">COMMISSION CHARGED ON P2P SETTLEMENTS</span>
                    <span className="text-sm font-black text-white font-sora mt-0.5 block tracking-wide">₹ 0.00 (100% Commission-Free)</span>
                  </div>

                </div>

                {/* Simulated Floating Badges floating around card */}
                <div className="absolute -top-6 -right-6 bg-slate-900 border border-slate-800 p-3 rounded-2xl flex items-center gap-2 shadow-lg animate-float">
                  <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center text-white text-xs font-bold">✓</div>
                  <div>
                    <span className="text-[9px] block text-slate-500 font-bold uppercase tracking-wide">MEMBER ACTIVE</span>
                    <span className="text-[11px] font-extrabold text-white block">Gym Fees Settle</span>
                  </div>
                </div>

                <div className="absolute -bottom-6 -left-6 bg-slate-900 border border-slate-800 p-3 rounded-2xl flex items-center gap-2 shadow-lg animate-float-slow">
                  <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white text-xs font-bold">⚡</div>
                  <div>
                    <span className="text-[9px] block text-slate-500 font-bold uppercase tracking-wide">SECURE LINK</span>
                    <span className="text-[11px] font-extrabold text-white block">Short Token Active</span>
                  </div>
                </div>

              </div>
              
            </div>
          </div>
        </section>

        {/* 3. Works with every UPI app Logo Ribbon */}
        <section className="bg-[#050810]/80 border-t border-b border-slate-900/60 py-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-6">
              <span className="text-[10px] text-slate-450 uppercase tracking-[0.25em] font-black font-mono block">
                Works with every UPI app
              </span>
            </div>
            
            {/* Horizontal Flex Grid of stylized UPI apps */}
            <div className="flex flex-wrap justify-center items-center gap-4 sm:gap-6 md:gap-8 opacity-90">
              
              {/* Paytm */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-blue-600/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center text-[10px] text-white font-black">p</span>
                <span className="text-xs font-bold text-white tracking-tight">paytm</span>
              </div>

              {/* BHIM */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-orange-600/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-orange-500 flex items-center justify-center text-[10px] text-white font-black">B</span>
                <span className="text-xs font-bold text-white tracking-tight">BHIM</span>
              </div>

              {/* CRED */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-purple-600/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-slate-950 flex items-center justify-center text-[10px] text-emerald-400 font-extrabold border border-indigo-500/20">C</span>
                <span className="text-xs font-bold text-white tracking-tight">CRED</span>
              </div>

              {/* Amazon Pay */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-yellow-600/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-yellow-500/20 flex items-center justify-center text-[11px] text-yellow-400 font-black">a</span>
                <span className="text-xs font-bold text-slate-300 tracking-tight">Amazon Pay</span>
              </div>

              {/* WhatsApp Pay */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-emerald-600/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-[10px] text-white font-bold">W</span>
                <span className="text-xs font-bold text-white tracking-tight">WhatsApp Pay</span>
              </div>

              {/* MobiKwik */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-blue-500/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-[10px] text-white font-bold">M</span>
                <span className="text-xs font-bold text-white tracking-tight">MobiKwik</span>
              </div>

              {/* Slice */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-pink-600/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-[#11052C] flex items-center justify-center text-[10px] text-pink-400 border border-pink-500/10 font-bold">slice</span>
                <span className="text-xs font-bold text-slate-300 tracking-tight">slice</span>
              </div>

              {/* super.money */}
              <div className="flex items-center gap-2 px-3.5 py-2 bg-slate-900/40 border border-slate-850/50 rounded-full select-none hover:border-lime-500/30 transition-all">
                <span className="w-5 h-5 rounded-full bg-lime-400 flex items-center justify-center text-[10px] text-slate-950 font-black">$</span>
                <span className="text-xs font-bold text-slate-200 tracking-tight">super.money</span>
              </div>

            </div>
          </div>
        </section>

        {/* 4. Why ZuelPay (Why UPIPE) Bento GRID - 0% MDR, 6-Tile Layout */}
        <section id="why-zuelpay" className="py-20 bg-[#070a14] border-b border-slate-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-14">
              <span className="text-xs bg-indigo-500/10 text-indigo-400 font-extrabold px-3 py-1.5 rounded-full border border-indigo-500/20 uppercase tracking-widest">
                Direct Settlement Advantage
              </span>
              <h2 className="text-3xl font-extrabold text-white mt-4 font-sora tracking-tight">Why ZuelPay Platform?</h2>
              <p className="text-sm text-slate-400 mt-2 max-w-lg mx-auto">
                Discover the peer-to-peer open protocol architecture that cuts intermediate fee layers entirely.
              </p>
            </div>

            {/* 6 Grid Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              
              {/* Tile 1 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6.5 rounded-2xl flex flex-col justify-between hover:border-indigo-500/35 transition-all shadow-lg group">
                <div className="space-y-3">
                  <div className="w-9 h-9 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400 border border-indigo-500/15 text-xs font-extrabold">0%</div>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider font-sora">0% MDR, 0% fees</h4>
                  <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                    UPI payments to your bank account carry zero intermediary fees and 0% commission.
                  </p>
                </div>
              </div>

              {/* Tile 2 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6.5 rounded-2xl flex flex-col justify-between hover:border-indigo-500/35 transition-all shadow-lg group">
                <div className="space-y-3">
                  <div className="w-9 h-9 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-400 border border-blue-500/15 text-xs font-extrabold">🏦</div>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider font-sora">Savings &amp; current accounts</h4>
                  <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                    Collect money straight into any account linked to a UPI ID — savings or current accounts.
                  </p>
                </div>
              </div>

              {/* Tile 3 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6.5 rounded-2xl flex flex-col justify-between hover:border-indigo-500/35 transition-all shadow-lg group">
                <div className="space-y-3">
                  <div className="w-9 h-9 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-400 border border-emerald-500/15 text-xs font-extrabold">✓</div>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider font-sora">No KYC for current accounts</h4>
                  <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                    If your business already has a current account, no extra KYC is needed to receive instant UPI payments.
                  </p>
                </div>
              </div>

              {/* Tile 4 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6.5 rounded-2xl flex flex-col justify-between hover:border-indigo-500/35 transition-all shadow-lg group">
                <div className="space-y-3">
                  <div className="w-9 h-9 bg-rose-500/10 rounded-xl flex items-center justify-center text-rose-400 border border-rose-500/15 text-xs font-extrabold">⚡</div>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider font-sora">Instant settlement</h4>
                  <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                    Funds land in your bank account within seconds. No T+1 day settlement wait, no artificial payout schedules.
                  </p>
                </div>
              </div>

              {/* Tile 5 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6.5 rounded-2xl flex flex-col justify-between hover:border-indigo-500/35 transition-all shadow-lg group">
                <div className="space-y-3">
                  <div className="w-9 h-9 bg-yellow-500/10 rounded-xl flex items-center justify-center text-yellow-400 border border-yellow-500/15 text-xs font-extrabold">⚙</div>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider font-sora">No UPI registration</h4>
                  <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                    You don't need to register with any third-party gateway aggregator to instantly generate a QR or link.
                  </p>
                </div>
              </div>

              {/* Tile 6 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6.5 rounded-2xl flex flex-col justify-between hover:border-indigo-500/35 transition-all shadow-lg group">
                <div className="space-y-3">
                  <div className="w-9 h-9 bg-purple-500/10 rounded-xl flex items-center justify-center text-purple-400 border border-purple-500/15 text-xs font-extrabold">📱</div>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider font-sora">Works on every UPI app</h4>
                  <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                    One single QR code scans instantly on GPay, PhonePe, Paytm, BHIM, CRED and every other UPI-compliant app.
                  </p>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* 5. How to generate a UPI QR code step-by-step Timeline */}
        <section id="how-to-generate" className="py-20 border-b border-slate-900/70">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="text-xs bg-indigo-500/10 text-indigo-400 font-extrabold px-3 py-1.5 rounded-full border border-indigo-500/20 uppercase tracking-widest">
                Quick Setup Method
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-4 font-sora tracking-tight">How to Generate a UPI QR Code</h2>
            </div>

            <div className="relative border-l border-slate-800 ml-6 pl-10 space-y-12">
              
              {/* Step 1 */}
              <div className="relative">
                <div className="absolute -left-[53px] top-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold border-4 border-[#020617] ring-2 ring-blue-500/30">1</div>
                <h3 className="text-sm font-bold text-white font-sora uppercase tracking-wider">Configure UPI ID Details</h3>
                <p className="text-[12px] text-slate-400 mt-2.5 leading-relaxed font-sans">
                  Pick the UPI ID parameters block and type your verified bank UPI handle/VPA (e.g., <code className="text-blue-400 font-mono text-[11px]">yourname@okhdfc</code> or <code className="text-blue-400 font-mono text-[11px]">mobile@paytm</code>).
                </p>
              </div>

              {/* Step 2 */}
              <div className="relative">
                <div className="absolute -left-[53px] top-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold border-4 border-[#020617] ring-2 ring-blue-500/30">2</div>
                <h3 className="text-sm font-bold text-white font-sora uppercase tracking-wider">Optionally Add Amount &amp; Business Name</h3>
                <p className="text-[12px] text-slate-400 mt-2.5 leading-relaxed font-sans">
                  Optionally add a target payment amount. <span className="text-indigo-300 font-semibold">Pro tip:</span> Leave the name field empty — your consumer's UPI mobile application will automatically fetch and display your verified bank name instead, which avoids name-mismatch warnings.
                </p>
              </div>

              {/* Step 3 */}
              <div className="relative">
                <div className="absolute -left-[53px] top-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold border-4 border-[#020617] ring-2 ring-blue-500/30">3</div>
                <h3 className="text-sm font-bold text-white font-sora uppercase tracking-wider">Share Link, Standee, or QR Code</h3>
                <p className="text-[12px] text-slate-400 mt-2.5 leading-relaxed font-sans">
                  Copy the high-speed compiled token link, download the high-resolution vector styled standalone placard JPG, or share it immediately. Anyone with a UPI app can pay you instantly in seconds.
                </p>
              </div>

            </div>
          </div>
        </section>

        {/* 5.1 Real-time Audit logs features block */}
        <section id="features-section" className="py-16 bg-[#070a14] relative border-b border-slate-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-10">
              <span className="text-xs bg-indigo-500/10 text-indigo-400 font-extrabold px-3 py-1.5 rounded-full border border-indigo-500/20 uppercase tracking-widest">
                Features Showcase
              </span>
              <h2 className="text-3xl font-extrabold text-white mt-4 font-sora tracking-tight">Decentralized P2P Settle Suite</h2>
              <p className="text-sm text-slate-400 mt-2 max-w-lg mx-auto">
                No third-party payout commissions or automated freeze loops. Manage manual settlements with startup-grade utilities.
              </p>
            </div>

            {/* Bento Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Feature 1: Manual Verification (Double Column width on MD) */}
              <div className="md:col-span-2 bg-[#0E1528] border border-slate-800 p-8 rounded-3xl hover:border-blue-600/60 duration-300 transition-all flex flex-col justify-between group">
                <div>
                  <div className="w-11 h-11 bg-blue-600/15 rounded-xl flex items-center justify-center border border-blue-500/30 text-blue-400 mb-6">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white font-sora">Safe Manual Verification Ledger</h3>
                  <p className="text-xs text-slate-400 mt-2.5 leading-relaxed max-w-xl">
                    Instead of routing your funds through unstable third-party PGs that freeze accounts or hold payouts, receive payments instantly into your bank ledger. Verify manually using customer-submitted transaction reference IDs (UTR).
                  </p>
                </div>
                <div className="mt-8 flex items-center gap-1.5 text-xs text-blue-400 font-extrabold uppercase tracking-wider group-hover:translate-x-1.5 transition-transform duration-300">
                  <span>Explore Admin Panels</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>

              {/* Feature 2: Smart QR Builder */}
              <div className="bg-[#0E1528] border border-slate-800 p-8 rounded-3xl hover:border-blue-600/60 duration-300 transition-all flex flex-col justify-between group">
                <div>
                  <div className="w-11 h-11 bg-indigo-600/15 rounded-xl flex items-center justify-center border border-indigo-500/30 text-indigo-400 mb-6">
                    <QrCode className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white font-sora">Locked-Amount UPI QR</h3>
                  <p className="text-xs text-slate-400 mt-2.5 leading-relaxed">
                    Prevent customer typo errors! Generate static or amount-locked UPI dynamic QR codes that pre-define pay notes securely inside banking frameworks.
                  </p>
                </div>
                <span className="block mt-6 border-t border-slate-800/80 pt-4 text-[10px] text-slate-550 font-mono">STANDARDIZED BHIM UPI SCHEME</span>
              </div>

              {/* Feature 3: Analytics Dashboard */}
              <div className="bg-[#0E1528] border border-slate-800 p-8 rounded-3xl hover:border-blue-600/60 duration-300 transition-all flex flex-col justify-between group">
                <div>
                  <div className="w-11 h-11 bg-emerald-600/15 rounded-xl flex items-center justify-center border border-emerald-500/30 text-emerald-400 mb-6">
                    <Activity className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white font-sora">Invoice Performance Analytics</h3>
                  <p className="text-xs text-slate-400 mt-2.5 leading-relaxed">
                    Track your daily invoice volume, pending manual verifications count, rejection metrics and performance summaries in real-time.
                  </p>
                </div>
                <span className="block mt-6 border-t border-slate-800/80 pt-4 text-[10px] text-slate-550 font-mono">LOCAL DB persistence engine</span>
              </div>

              {/* Feature 4: Short Link Token (Double Column width on MD) */}
              <div className="md:col-span-2 bg-[#0E1528] border border-slate-800 p-8 rounded-3xl hover:border-blue-600/60 duration-300 transition-all flex flex-col justify-between group">
                <div>
                  <div className="w-11 h-11 bg-purple-600/15 rounded-xl flex items-center justify-center border border-purple-500/30 text-purple-400 mb-6">
                    <Zap className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white font-sora">Compact Base64 Short Token Encapsulator</h3>
                  <p className="text-xs text-slate-400 mt-2.5 leading-relaxed max-w-xl">
                    Long, ugly URLs with visible parameters look spammy and reduce transaction conversions. Our generator collapses billing data (Amount, Notes, UPI VPA) into an elegant Base64 token parameters that keep checkout links clean and professional.
                  </p>
                </div>
                <div className="mt-8 text-[10px] font-mono text-slate-450 hover:text-white transition-colors">
                  Example: {window.location.origin}/?d=MTUwMH5HeW0lMjBNZW...
                </div>
              </div>

            </div>

          </div>
        </section>

        {/* 6. Live Interactive Symmetrical Invoice Workspace Panel Section */}
        <section id="interactive-workspace" className="py-20 md:py-28 relative">
          
          <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-[140px] pointer-events-none select-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
            
            {/* Workbench Title Header */}
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="text-xs bg-emerald-500/10 text-emerald-400 font-extrabold px-3 py-1.5 rounded-full border border-emerald-500/20 uppercase tracking-widest">
                Interactive Playground
              </span>
              <h2 className="text-3xl font-extrabold text-white mt-4 font-sora tracking-tight">Interactive Invoice Workbench</h2>
              <p className="text-sm text-slate-400 mt-2 max-w-xl mx-auto">
                No signups needed. Try configuring your active payment parameters, lock them onto a private profile, and checkout with direct short links.
              </p>
            </div>

            {/* TWO-COLUMN WORKBENCH */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
              
              {/* Profile Config CARD (Left 6 columns) */}
              <div className="lg:col-span-6 bg-slate-950/40 backdrop-blur-xl border border-slate-800/80 p-6 sm:p-8 rounded-3xl flex flex-col justify-between shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] relative overflow-hidden group hover:border-blue-500/20 transition-all duration-500">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-transparent opacity-40"></div>
                
                <div className="space-y-6">
                  <div className="pb-4 border-b border-slate-800/60">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] bg-blue-500/10 text-blue-400 font-extrabold px-2.5 py-1 rounded-md uppercase tracking-wider border border-blue-500/20 select-none">
                        Active Database Sandbox
                      </span>
                      <span className="flex items-center gap-1 text-[9px] text-emerald-400 font-mono">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                        LOCAL RECON LOGS ACTIVE
                      </span>
                    </div>
                    <h3 className="text-lg font-extrabold text-white mt-3 flex items-center gap-2 font-sora tracking-tight">
                      <User className="w-5 h-5 text-blue-400" />
                      Step A: Payee Account Details
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      Enter your payee name and bank UPI ID. Stored directly in your browser so all generated QR codes route funds directly to your bank account.
                    </p>
                  </div>

                  <form onSubmit={handleSaveProfile} className="space-y-5">
                    
                    {validationError && (
                      <div className="p-3.5 bg-red-500/10 text-red-400 border border-red-500/20 rounded-xl text-xs font-semibold animate-shake">
                        ⚠️ {validationError}
                      </div>
                    )}

                    {profileSaved && (
                      <div className="p-3.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 rounded-xl text-xs font-bold flex items-center gap-2 animate-bounce">
                        <CheckCircle className="w-4.5 h-4.5 text-emerald-400 flex-shrink-0" />
                        <span>Profile synchronized successfully with browser IndexedDB! Dynamic links updated.</span>
                      </div>
                    )}

                    <div className="space-y-2">
                      <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">Payee / Account Name *</label>
                      <div className="relative group">
                        <User className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-blue-400 transition-colors" />
                        <input
                          type="text"
                          required
                          placeholder="e.g., Alex Sharma, Personal Studio, Store"
                          value={profileName}
                          onChange={e => setProfileName(e.target.value)}
                          className="w-full bg-[#040812]/60 text-white border border-slate-800 focus:border-blue-500 focus:bg-[#040812]/80 focus:shadow-[0_0_15px_rgba(59,130,246,0.15)] rounded-xl p-3.5 pl-10.5 text-xs font-bold outline-none transition-all placeholder:text-slate-600"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block font-sans">Bank VPA UPI ID Address *</label>
                        <span className="text-[8px] text-blue-400 font-bold uppercase bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">DIRECT ASSET DESTINATION</span>
                      </div>
                      <div className="relative group">
                        <QrCode className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-blue-400 transition-colors" />
                        <input
                          type="text"
                          required
                          placeholder="e.g., business@oksbi, or yourname@oksbi"
                          value={profileUpi}
                          onChange={e => setProfileUpi(e.target.value)}
                          className="w-full bg-[#040812]/60 text-white border border-slate-800 focus:border-blue-550 focus:shadow-[0_0_15px_rgba(59,130,246,0.15)] rounded-xl p-3.5 pl-10.5 text-xs font-extrabold font-mono text-indigo-350 outline-none transition-all placeholder:text-slate-600"
                        />
                      </div>
                      <p className="text-[10px] text-slate-505 leading-relaxed">Your digital banking VPA handle to verify and credit transfers directly into accounts.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      <div className="space-y-2">
                        <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">WhatsApp Support desk</label>
                        <div className="relative group">
                          <MessageCircle className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-blue-400 transition-colors" />
                          <input
                            type="tel"
                            placeholder="e.g., 7996989956"
                            value={profileWhatsApp}
                            onChange={e => setProfileWhatsApp(e.target.value)}
                            className="w-full bg-[#040812]/60 text-white border border-slate-800 focus:border-blue-550 rounded-xl p-3.5 pl-10.5 text-xs font-mono outline-none transition-all placeholder:text-slate-600"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">Support Desk E-mail</label>
                        <div className="relative group">
                          <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-blue-400 transition-colors" />
                          <input
                            type="email"
                            placeholder="e.g., billings@apex.com"
                            value={profileEmail}
                            onChange={e => setProfileEmail(e.target.value)}
                            className="w-full bg-[#040812]/60 text-white border border-slate-800 focus:border-blue-550 rounded-xl p-3.5 pl-10.5 text-xs outline-none transition-all placeholder:text-slate-600"
                          />
                        </div>
                      </div>

                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-650 hover:from-blue-550 hover:to-indigo-600 text-white font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all shadow-xl shadow-blue-500/10 flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.01] active:scale-[0.99] group"
                      >
                        <Save className="w-4 h-4 text-blue-200 group-hover:rotate-6 transition-transform" />
                        <span>Save Payee Details to Browser</span>
                      </button>
                    </div>

                  </form>
                </div>

                {/* Advanced Security & Safety Guide checklist to enrich empty space */}
                <div className="my-6 p-4 sm:p-5 bg-[#030712]/50 border border-slate-900 rounded-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-3 text-blue-500/5">
                    <ShieldCheck className="w-20 h-20 pointer-events-none" />
                  </div>
                  <span className="text-[9.5px] bg-blue-500/10 text-blue-400 font-extrabold px-2.5 py-1 rounded-md border border-blue-500/15 uppercase tracking-wider block w-fit mb-3.5 select-none hover:border-blue-550 transition-colors">
                    🛡️ ZuelPay Safety Operations Protocol
                  </span>
                  <div className="space-y-3.5 text-xs text-slate-300">
                    <div className="flex items-start gap-2.5">
                      <div className="w-5 h-5 rounded bg-blue-500/10 border border-blue-500/30 font-bold flex items-center justify-center text-blue-400 text-[10px] shrink-0 mt-0.5 select-none">01</div>
                      <div>
                        <h4 className="font-extrabold text-slate-200 text-[11px] leading-tight flex items-center gap-1">VPA Coordinate Verification</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">Ensure your bank Virtual Private Address (VPA) is typed exactly right. ZuelPay routes transactions on direct rails, meaning money goes directly. Incorrect VPAs will misroute transfers.</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-2.5">
                      <div className="w-5 h-5 rounded bg-indigo-500/10 border border-indigo-500/30 font-bold flex items-center justify-center text-indigo-400 text-[10px] shrink-0 mt-0.5 select-none">02</div>
                      <div>
                        <h4 className="font-extrabold text-slate-200 text-[11px] leading-tight mb-0.5">Commission-Free Sovereignty</h4>
                        <p className="text-[10px] text-slate-500 leading-relaxed">All incoming client invoice cash amounts belong 100% to you. ZuelPay never interacts with intermediate payment processors or collects fees, guarding you from gateway leakage.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <div className="w-5 h-5 rounded bg-emerald-500/10 border border-emerald-500/30 font-bold flex items-center justify-center text-emerald-400 text-[10px] shrink-0 mt-0.5 select-none">03</div>
                      <div>
                        <h4 className="font-extrabold text-slate-200 text-[11px] leading-tight mb-0.5">Human Verification Standard</h4>
                        <p className="text-[10px] text-slate-500 leading-relaxed">Always check your dedicated offline bank statement (such as standard mobile alerts) to confirm matching 12-digit customer UTR digits prior to pressing the settle button.</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Playbook micro guide */}
                <div className="mt-2 pt-4 border-t border-slate-800/60 z-10">
                  <div className="flex items-center gap-1.5 mb-3">
                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Security Isolation</span>
                  </div>
                  <p className="text-[10.5px] text-slate-400 leading-relaxed font-sans">
                    ZuelPay uses an on-device sandboxing protocol. All credential coordinates reside 100% locally inside your browser's private secure memory registers. No payment details are ever broadcast or saved onto third-party servers.
                  </p>
                </div>

              </div>

              {/* QR Amount Generator CARD (Right 6 columns) */}
              <div className="lg:col-span-6 bg-[#0E1528] bg-slate-950/40 backdrop-blur-xl border border-slate-800/80 p-6 sm:p-8 rounded-3xl flex flex-col justify-between shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] relative overflow-hidden group hover:border-emerald-500/20 transition-all duration-500">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-transparent opacity-40"></div>
                
                <div className="space-y-5">
                  <div className="pb-4 border-b border-slate-800/80">
                    <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-extrabold px-2.5 py-1 rounded-md uppercase tracking-wider border border-emerald-500/20 select-none">
                      Dynamic Payload Compiler
                    </span>
                    <h3 className="text-lg font-extrabold text-white mt-3 flex items-center gap-2 font-sora tracking-tight">
                      <QrCode className="w-5 h-5 text-emerald-400 animate-pulse" />
                      Step B: Custom Amount Link Generator
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      Lock dynamic parameters like billing amount or remarks to generate error-free instant checkout codes for buyers.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block font-sans">Billing Amount (INR)</label>
                      <div className="relative group">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-black text-xs text-slate-500 group-focus-within:text-emerald-400">₹</span>
                        <input
                          type="number"
                          placeholder="e.g., 1500 (Optional)"
                          value={payAmount}
                          onChange={e => setPayAmount(e.target.value)}
                          className="w-full bg-[#040812]/60 text-white border border-slate-800 focus:border-emerald-500 rounded-xl p-3.5 pl-8 text-xs font-black font-mono outline-none transition-all placeholder:text-slate-600"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block font-sans font-sans">Voucher Remarks / Purpose</label>
                      <input
                        type="text"
                        placeholder="e.g., Monthly Gym Fees, Web Dev Project"
                        value={payNote}
                        onChange={e => setPayNote(e.target.value)}
                        className="w-full bg-[#040812]/60 text-white border border-slate-800 focus:border-emerald-500 rounded-xl p-3.5 px-4 text-xs font-bold outline-none transition-all placeholder:text-slate-600"
                      />
                    </div>

                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block font-sans">Buyer WhatsApp (Mobile Entry)</label>
                      <span className="text-[8px] text-emerald-400 font-mono font-bold uppercase">Preloads Direct Message</span>
                    </div>
                    <input
                      type="tel"
                      placeholder="e.g., 7996989956 (Forces WhatsApp checkout routing)"
                      value={customerMobile}
                      onChange={e => setCustomerMobile(e.target.value.replace(/[^0-9]/g, ''))}
                      className="w-full bg-[#040812]/60 text-white border border-slate-800 focus:border-emerald-500 rounded-xl p-3.5 px-4 text-xs font-mono font-bold outline-none transition-all placeholder:text-slate-600"
                    />
                  </div>

                  {/* QR Core Showcase with custom neon ring */}
                  <div className="p-5 bg-slate-950 border border-slate-800/80 rounded-2xl flex flex-col items-center justify-center relative overflow-hidden group shadow-lg">
                    <div className="absolute inset-0 bg-radial-gradient(circle_at_center,rgba(16,185,129,0.03)_0%,transparent_70%) pointer-events-none"></div>
                    
                    <div className="p-2.5 bg-slate-900 border-2 border-emerald-500/20 hover:border-emerald-500/40 transition-colors rounded-2xl shadow-[0_0_30px_rgba(16,185,129,0.05)]">
                      <QRCodeGenerator 
                        upiId={activeUpi} 
                        businessName={activeName} 
                        amount={payAmount ? parseFloat(payAmount) : undefined} 
                        remarks={payNote}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-slate-500 mt-3 uppercase tracking-widest font-extrabold text-center block">
                      UPINote dynamic cryptograph payload template
                    </span>
                  </div>

                  {/* Compacted Base64 dynamic links */}
                  <div className="pt-2 space-y-1.5 text-left">
                    <div className="flex justify-between items-center">
                      <span className="text-[9.5px] font-extrabold uppercase tracking-widest text-slate-400 font-sora">🔗 Sandbox Compiled Checkout URL</span>
                      <span className="text-blue-400 font-mono text-[8.5px] font-extrabold uppercase tracking-wider bg-blue-500/10 px-1.5 py-0.5 rounded border border-blue-500/15">COMPRESS_V3</span>
                    </div>

                    <div className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl flex items-center justify-between gap-3 shadow-inner hover:border-blue-500/30 transition-all">
                      <input
                        type="text"
                        readOnly
                        value={liveCheckoutUrl}
                        className="bg-transparent border-none text-[10.5px] font-mono text-indigo-300 font-medium focus:text-white outline-none w-full select-all truncate"
                      />
                      <button
                        type="button"
                        onClick={handleCopyLink}
                        className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-all cursor-pointer flex-shrink-0"
                        title="Copy dynamic payload link"
                      >
                        {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Link Shortener Block */}
                  <div className="pt-4 border-t border-slate-850/80 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-extrabold px-2.5 py-1 rounded-md uppercase tracking-wider border border-indigo-500/15 flex items-center gap-1 leading-none select-none">
                        <Zap className="w-3.5 h-3.5 text-indigo-400 fill-indigo-400/20" />
                        Bitly-Style Token Shortener
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={handleGenerateShortLink}
                      disabled={isShortening}
                      className="w-full py-3.5 bg-gradient-to-r from-indigo-650 to-purple-650 hover:from-indigo-600 hover:to-purple-600 disabled:opacity-50 text-white font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.01] active:scale-[0.99] group"
                    >
                      {isShortening ? (
                        <>
                          <RefreshCw className="w-4 h-4 text-indigo-200 animate-spin" />
                          <span>COLLAPSING TOKEN STRINGS...</span>
                        </>
                      ) : (
                        <>
                          <Link2 className="w-4 h-4 text-indigo-200" />
                          <span>Shorten with ZuelPay (Bitly-Style)</span>
                        </>
                      )}
                    </button>

                    {shortenedUrl && (
                      <div className="p-3.5 bg-indigo-950/25 border border-indigo-900/40 rounded-xl space-y-2.5 animate-fade-in relative shadow-md">
                        <div className="flex justify-between items-center text-[9px] font-black text-indigo-400">
                          <span>YOUR SHORTENED RECON LINK CODE:</span>
                          <span className="text-emerald-400 font-bold uppercase">ACTIVE ON CLOUD RUN</span>
                        </div>
                        <div className="flex items-center justify-between gap-2 bg-slate-950 p-2.5 rounded-lg border border-indigo-950/80">
                          <span className="text-[11px] font-mono text-indigo-200 font-black select-all truncate">{shortenedUrl}</span>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(shortenedUrl);
                              setCopiedShort(true);
                              setTimeout(() => setCopiedShort(false), 2000);
                              setToastMessage("📋 Shorten Link copied to clipboard!");
                              setTimeout(() => setToastMessage(''), 3000);
                            }}
                            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-all cursor-pointer"
                          >
                            {copiedShort ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <p className="text-[9.5px] text-slate-450 leading-relaxed font-sans">Share this Bitly-style shortened URL to customers. It handles all variables securely inside a 5-digit index record.</p>
                      </div>
                    )}
                  </div>

                  {/* Actions buttons */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <button
                      type="button"
                      onClick={handleWhatsAppShare}
                      disabled={!activeUpi}
                      className="py-3.5 px-4 bg-emerald-600 hover:bg-emerald-550 text-white rounded-xl font-extrabold text-xs uppercase tracking-widest hover:scale-[1.01] active:scale-[0.99] transition-all shadow-md shadow-emerald-500/10 disabled:opacity-50 disabled:pointer-events-none cursor-pointer flex items-center justify-center gap-2 group"
                    >
                      <MessageCircle className="w-4 h-4 text-emerald-250 group-hover:translate-x-0.5 transition-transform" />
                      <span>WhatsApp Settle Invoice</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRoute('payment')}
                      className="py-3.5 px-4 bg-slate-900 hover:bg-slate-850 text-slate-250 hover:text-white rounded-xl font-extrabold text-xs uppercase tracking-widest border border-slate-800 hover:border-slate-700 transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Smartphone className="w-4 h-4 text-slate-500" />
                      <span>Test Checkout Screen</span>
                    </button>
                  </div>

                </div>

              </div>

            </div>

            {/* 🖥️ STEP C: P2P RECONCILIATION FLIGHT-SIMULATOR DASHBOARD (Full Width UI Upgrade) */}
            <div id="recon-simulator-dashboard" className="mt-16 bg-slate-950/55 backdrop-blur-2xl border border-slate-800/90 rounded-3xl p-6 sm:p-10 shadow-[0_30px_70px_-10px_rgba(0,0,0,0.85)] relative overflow-hidden group hover:border-indigo-500/20 transition-all duration-300">
              <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none select-none"></div>
              
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-slate-800/90 mb-8">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-gradient-to-r from-blue-600 to-indigo-500 text-white font-extrabold px-3 py-1 rounded-full uppercase tracking-widest border border-blue-500/30">
                      Interactive Sandbox Simulator
                    </span>
                    <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                  </div>
                  <h3 className="text-xl font-extrabold text-white font-sora mt-3 tracking-tight flex items-center gap-2.5">
                    <Activity className="w-5.5 h-5.5 text-blue-400" />
                    Step C: P2P Statement Sync Flight-Simulator
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
                    Test the complete ZuelPay loop right now without installing anything! Click the simulator triggers below to view exactly how a customer pay voucher matches raw bank ledger lines manually inside the Admin Console.
                  </p>
                </div>

                <div className="flex gap-2.5">
                  <button
                    onClick={() => {
                      setSimStep('idle');
                      setSimCopied(false);
                      setToastMessage("🔄 Simulator reset to initial state!");
                      setTimeout(() => setToastMessage(''), 2500);
                    }}
                    className="px-3.5 py-2 hover:bg-slate-850/80 text-slate-400 hover:text-white border border-slate-800 rounded-xl text-[10px] font-bold uppercase tracking-wider font-mono cursor-pointer transition-colors"
                  >
                    Reset Flight
                  </button>
                </div>
              </div>

              {/* Simulation Stage Controller Timeline Buttons */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                
                <button
                  onClick={() => {
                    setSimStep('checkout');
                    setToastMessage("📱 Stage 1 Launched: Client Checkout Screen Panel!");
                    setTimeout(() => setToastMessage(''), 2500);
                  }}
                  className={`p-4 rounded-2xl text-left border transition-all duration-300 relative overflow-hidden cursor-pointer ${
                    simStep === 'checkout'
                      ? 'bg-blue-600/10 border-blue-500 shadow-[0_0_20px_rgba(37,99,235,0.15)]'
                      : 'bg-[#060a15] border-slate-800/80 hover:border-slate-700/80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-black uppercase text-blue-400 leading-none">STAGE 01</span>
                    <span className="text-xs">📲</span>
                  </div>
                  <h4 className="text-xs font-extrabold text-white font-sora leading-snug">Launch Client Checkout UI</h4>
                  <p className="text-[10px] text-slate-450 leading-relaxed mt-1">Simulate the buyer view seeing QR and locking their ₹1,500 bill.</p>
                  {simStep === 'checkout' && <div className="absolute right-0 bottom-0 w-1 h-full bg-blue-500"></div>}
                </button>

                <button
                  onClick={() => {
                    if (simStep === 'idle') setSimStep('checkout');
                    setTimeout(() => {
                      setSimStep('paid');
                      setToastMessage("💵 Stage 2 Loaded: Customer paid and submitted 12 digit reference UTR!");
                      setTimeout(() => setToastMessage(''), 3000);
                    }, 200);
                  }}
                  className={`p-4 rounded-2xl text-left border transition-all duration-300 relative overflow-hidden cursor-pointer ${
                    simStep === 'paid'
                      ? 'bg-indigo-600/10 border-indigo-500 shadow-[0_0_20px_rgba(79,70,229,0.15)]'
                      : 'bg-[#060a15] border-slate-800/80 hover:border-slate-700/80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-black uppercase text-indigo-405 leading-none">STAGE 02</span>
                    <span className="text-xs">💸</span>
                  </div>
                  <h4 className="text-xs font-extrabold text-white font-sora leading-snug">Simulate Deposit &amp; File</h4>
                  <p className="text-[10px] text-slate-450 leading-relaxed mt-1">Mock transaction success, copy reference UTR key to match statement.</p>
                  {simStep === 'paid' && <div className="absolute right-0 bottom-0 w-1 h-full bg-indigo-500"></div>}
                </button>

                <button
                  onClick={() => {
                    if (simStep === 'idle' || simStep === 'checkout') setSimStep('paid');
                    setTimeout(() => {
                      setSimStep('verified');
                      setToastMessage("🏆 Reconciled Successfully! Statement audit record matched 100%!");
                      setTimeout(() => setToastMessage(''), 4000);
                    }, 250);
                  }}
                  className={`p-4 rounded-2xl text-left border transition-all duration-300 relative overflow-hidden cursor-pointer ${
                    simStep === 'verified'
                      ? 'bg-emerald-600/10 border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.15)] animate-pulse'
                      : 'bg-[#060a15] border-slate-800/80 hover:border-slate-700/80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-black uppercase text-emerald-400 leading-none">STAGE 03</span>
                    <span className="text-xs">🎯</span>
                  </div>
                  <h4 className="text-xs font-extrabold text-white font-sora leading-snug">Manually Settle Ledger Row</h4>
                  <p className="text-[10px] text-slate-450 leading-relaxed mt-1">Cross-reference with bank statement logs &amp; confirm transfer.</p>
                  {simStep === 'verified' && <div className="absolute right-0 bottom-0 w-1 h-full bg-emerald-555"></div>}
                </button>

              </div>

              {/* Dynamic Flight Simulation Render Window */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-4 border-t border-slate-900">
                
                {/* Simulator Left Box: Render Simulated Device Checkouts */}
                <div className="lg:col-span-5 bg-black/40 border border-slate-900 rounded-2xl p-5 relative overflow-hidden flex flex-col justify-between">
                  <span className="absolute top-3 right-3 text-[8.5px] font-mono text-slate-600">SECURE_MOBILE_DEVICE</span>
                  
                  {simStep === 'idle' && (
                    <div className="my-10 text-center space-y-4 py-8">
                       <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500 animate-pulse text-lg">❔</div>
                      <h4 className="text-xs font-bold text-slate-200">Simulation Engine Waiting</h4>
                      <p className="text-[10px] text-slate-505 leading-relaxed max-w-xs mx-auto">
                        Select a simulator stage or touch the "Launch Client Checkout UI" stage block on top to load client transaction models.
                      </p>
                    </div>
                  )}

                  {(simStep === 'checkout' || simStep === 'paid' || simStep === 'verified') && (
                    <div className="space-y-4 animate-fade-in text-left">
                      
                      <div className="flex items-center gap-1.5 pb-2 border-b border-slate-900/60">
                        <div className="w-5 h-5 bg-gradient-to-tr from-blue-500 to-indigo-500 rounded flex items-center justify-center text-[10px] font-black text-white">Z</div>
                        <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-mono">ZuelPay Client Terminal</span>
                      </div>

                      <div className="p-4 bg-[#050810]/95 border border-slate-850 rounded-xl space-y-3">
                        <span className="text-[8px] font-mono text-slate-550 bg-slate-950 px-2 py-0.5 rounded uppercase">SCAN SUCCESS</span>
                        <div className="space-y-0.5">
                          <p className="text-[10px] text-slate-400">Paying To VPA</p>
                          <p className="text-xs font-extrabold text-white">{activeName}</p>
                          <p className="text-[9.5px] font-mono text-blue-400/90 leading-none font-bold select-all">{activeUpi}</p>
                        </div>
                        <div className="pt-2 border-t border-slate-900 flex justify-between items-center">
                          <span className="text-[10px] text-slate-500">Locked Amount</span>
                          <span className="text-sm font-black text-white font-mono">₹{simAmount}.00</span>
                        </div>
                      </div>

                      {simStep === 'checkout' && (
                        <div className="p-3 bg-blue-500/10 border border-blue-500/15 rounded-xl space-y-2">
                          <span className="text-[8px] font-mono font-black text-blue-400 uppercase block">SIMULATOR ACTION REQ:</span>
                          <p className="text-[10px] text-slate-350 leading-relaxed font-sans">
                            The buyer preloads this. Tap <strong className="text-white font-bold">"Simulate Deposit &amp; File"</strong> stage button to make payment inside client's hand and get transaction UTR hash.
                          </p>
                        </div>
                      )}

                      {(simStep === 'paid' || simStep === 'verified') && (
                        <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl space-y-2.5 animate-bounce">
                          <div className="flex justify-between items-center text-[8.5px] font-bold text-emerald-450 uppercase font-mono tracking-wider">
                            <span>💸 UPI TRANSACTION DEPOSITED</span>
                            <span className="text-emerald-450">TXN_SUCCESS</span>
                          </div>
                          <div className="text-xs">
                            <span className="text-slate-400 block text-[9px] uppercase tracking-wide">12-Digit Receipt UTR Code:</span>
                            <div className="flex items-center justify-between gap-1 mt-1 bg-slate-950 p-1.5 px-2.5 rounded-lg border border-emerald-950/80">
                              <span className="text-xs font-mono font-black text-teal-400 leading-none select-all">{simUtr}</span>
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(simUtr);
                                  setSimCopied(true);
                                  setTimeout(() => setSimCopied(false), 2500);
                                  setToastMessage("📋 Mock Reference UTR Code copied to clipboard!");
                                  setTimeout(() => setToastMessage(''), 2500);
                                }}
                                className="text-[8.5px] text-emerald-450 hover:text-white transition-colors"
                              >
                                {simCopied ? 'Copied ✓' : 'Copy UTR'}
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      <p className="text-[8.5px] text-slate-500 italic">This layout mimics client checkouts. Real checkouts capture direct statement reference codes.</p>
                    </div>
                  )}

                  <div className="text-slate-600 font-mono text-[9px] text-center pt-2 leading-none border-t border-slate-900/60 mt-4">
                    SIM PORTAL ENCRYPTED OVER HTTPS
                  </div>
                </div>

                {/* Simulator Right Box: Render Simulated Administrator Statement Auditing */}
                <div className="lg:col-span-7 bg-black/40 border border-slate-900 rounded-2xl p-5 relative overflow-hidden flex flex-col justify-between">
                  <span className="absolute top-3 right-3 text-[8.5px] font-mono text-slate-600">ADMIN_STATEMENT_LEDGER_RECONCILE</span>
                  
                  <div className="text-left space-y-4">
                    
                    <div className="flex items-center gap-1.5 pb-2 border-b border-slate-900/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest font-mono">Private Bank Statement Live Crawler</span>
                    </div>

                    <div className="space-y-2">
                      <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">Real-time Incoming credit feeds (Mock Bank API):</span>
                      
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-[10px] sm:text-[11px] font-mono select-none">
                          <thead>
                            <tr className="border-b border-slate-900 text-slate-600 text-[8.5px] font-bold">
                              <th className="pb-1">Credit Time</th>
                              <th className="pb-1">Details/UTR</th>
                              <th className="pb-1 text-right">Sum Deposited</th>
                              <th className="pb-1 text-right">Audit Match</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-900">
                            
                            <tr className="text-slate-500 hover:bg-slate-900/10">
                              <td className="py-2 text-[9px] text-slate-600">12:31:05</td>
                              <td className="py-2 text-[9px]">UPI/CR/923847841923/Roy_T</td>
                              <td className="py-2 text-right font-bold text-slate-400">₹850.00</td>
                              <td className="py-2 text-right text-emerald-500 font-bold">✓ RECON</td>
                            </tr>

                            {/* Dynamic Row appearing on state paid or verified */}
                            {(simStep === 'paid' || simStep === 'verified') ? (
                              <tr className={`hover:bg-indigo-950/20 transition-all font-bold ${simStep === 'paid' ? 'bg-indigo-900/10 text-white animate-pulse border-y border-indigo-900/50' : 'text-emerald-400'}`}>
                                <td className="py-2.5 text-[9px] text-[#2563EB]">12:35:10</td>
                                <td className="py-2.5 text-[9px]">
                                  <span className="block text-indigo-350">UPI/CR/{simUtr}/{simRemarks.substring(0, 5)}</span>
                                  <span className="block text-[8px] font-sans text-slate-600 italic">Incoming direct VPA transfer</span>
                                </td>
                                <td className="py-2.5 text-right text-white">₹{simAmount}.00</td>
                                <td className="py-2.5 text-right font-sans">
                                  {simStep === 'paid' ? (
                                    <span className="text-yellow-405 font-bold uppercase tracking-wider animate-pulse flex items-center justify-end gap-1 text-[8.5px]">
                                      ● MISMATCH CLAIM
                                    </span>
                                  ) : (
                                    <span className="text-emerald-400 font-extrabold uppercase tracking-wider flex items-center justify-end gap-1 text-[8.5px]">
                                      🎯 SETTLED OK
                                    </span>
                                  )}
                                </td>
                              </tr>
                            ) : (
                              <tr className="text-slate-600">
                                <td colSpan={4} className="py-3 text-center text-slate-505 text-[9.5px]">Waiting for Stage 2 cash transfer to trigger raw ledger lines...</td>
                              </tr>
                            )}

                            <tr className="text-slate-500 hover:bg-slate-900/10">
                              <td className="py-2 text-[9px] text-slate-600">12:28:14</td>
                              <td className="py-2 text-[9px]">UPI/CR/328905141521/Apex_C</td>
                              <td className="py-2 text-right font-bold text-slate-400">₹3,000.00</td>
                              <td className="py-2 text-right text-emerald-500 font-bold">✓ RECON</td>
                            </tr>

                          </tbody>
                        </table>
                      </div>

                    </div>

                    {/* Action Hub */}
                    {simStep === 'paid' && (
                      <div className="p-3 bg-indigo-950/30 border border-indigo-900/35 rounded-xl space-y-2.5 animate-fade-in text-xs">
                        <span className="text-[8.5px] uppercase font-black text-indigo-400 font-mono tracking-wider block">Recon Decision Desks Engine Active:</span>
                        <p className="text-[10px] text-slate-350 leading-relaxed font-sans">
                          A claim has registered! UTR identifier <code className="font-bold text-white font-mono">{simUtr}</code> is reported on your checkout index. Bank feed crawler has captured a direct credit of ₹1,500 with a matching reference! Settle now?
                        </p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              setSimStep('verified');
                              setToastMessage("🏆 Reconciled Successfully! Statement audit record matched 100%!");
                              setTimeout(() => setToastMessage(''), 4000);
                            }}
                            className="bg-emerald-600 hover:bg-emerald-550 border border-emerald-500/20 px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-white rounded-lg cursor-pointer transition-all hover:scale-101 active:scale-99 flex items-center gap-1.5"
                          >
                            <span>Approve &amp; Reconcile (Settle)</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {simStep === 'verified' && (
                      <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl space-y-2 animate-bounce text-xs">
                        <span className="text-[8.5px] uppercase font-black text-emerald-400 font-mono block">SETTLEMENT COMPLETE</span>
                        <p className="text-[10px] text-slate-300 leading-relaxed font-sans">
                          Symmetrical verification checks complete! Settle record updated inside sandbox database. Receipts archived and click metric updated. This keeps you protected against credit chargebacks automatically.
                        </p>
                      </div>
                    )}

                    <div className="pt-2 border-t border-slate-900">
                      <p className="text-[10px] text-slate-500 leading-relaxed">
                        <strong>The Value Proposition:</strong> Instead of routing your revenue through central payment processors that take 2% or block your money, ZuelPay routes funds directly into your bank and matches references on your private laptop screen securely!
                      </p>
                    </div>

                  </div>
                  
                  <div className="text-slate-600 font-mono text-[9px] text-center pt-2 leading-none border-t border-slate-900/60 mt-4">
                    BANK SECURE HANDSHAKE STATUS: SECURED OVER DIRECT CHANNEL
                  </div>
                </div>

              </div>

            </div>

          </div>

        </section>

        {/* 7. Reviews Testimonial Slider: Elegant glassmism visual */}
        <section id="testimonials-section" className="py-20 bg-[#070a14] border-t border-b border-indigo-950/20">
          <div className="max-w-4xl mx-auto px-4 text-center">
            
            <div className="flex justify-center mb-6">
              <div className="flex gap-1 text-yellow-400">
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
                <Star className="w-5 h-5 fill-current" />
              </div>
            </div>

            {/* Testimonial Active Quote block */}
            <div className="min-h-[140px] flex items-center justify-center">
              <p className="text-base sm:text-lg md:text-xl font-medium text-slate-200 italic leading-relaxed">
                "{testimonials[activeTestimonial].quote}"
              </p>
            </div>

            <div className="mt-6">
              <strong className="text-white text-sm block font-sora">{testimonials[activeTestimonial].author}</strong>
              <span className="text-xs text-slate-500 m-0.5 block">{testimonials[activeTestimonial].role} · {testimonials[activeTestimonial].location}</span>
            </div>

            {/* Carousel controllers */}
            <div className="mt-6 flex justify-center gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setActiveTestimonial(i)}
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-300 cursor-pointer ${i === activeTestimonial ? 'bg-blue-500 w-6' : 'bg-slate-800 hover:bg-slate-700'}`}
                ></button>
              ))}
            </div>

          </div>
        </section>

        {/* 8. Trust Banner Grid */}
        <section className="py-16 bg-[#0E1528]/40 border-b border-slate-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex gap-4 items-start">
                <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-sora">Safe &amp; Encrypted Ledgers</h4>
                  <p className="text-[11px] text-slate-450 leading-relaxed mt-1">Direct account transfers bypass third-party PGs, securing you against unexpected wallet freezes.</p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-10 h-10 rounded-xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                  <RefreshCw className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-sora">Manual Reconciliation Control</h4>
                  <p className="text-[11px] text-slate-450 leading-relaxed mt-1">Verify payment reference UTRs against your actual private bank statement log, putting you in control.</p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-10 h-10 rounded-xl bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-sora">Guaranteed Zero Gateway Fee</h4>
                  <p className="text-[11px] text-slate-450 leading-relaxed mt-1">Accept digital payments with 0% commissions forever. No hidden settlement charges or pricing tiers.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 8a. About bank-account QR codes Guide Section (Three Columns) */}
        <section className="py-20 bg-[#070a14] border-b border-slate-900/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-14">
              <span className="text-xs bg-blue-500/10 text-blue-400 font-extrabold px-3 py-1.5 rounded-full border border-blue-500/20 uppercase tracking-widest">
                Addressing Protocols
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-4 font-sora tracking-tight">About Bank-Account QR Codes</h2>
              <p className="text-xs text-slate-400 mt-2 max-w-md mx-auto">
                Read how modern UPI applications coordinate direct routing pathways.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* Column 1 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6 rounded-2xl space-y-3">
                <div className="w-10 h-10 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl flex items-center justify-center text-sm font-black">
                  🗙
                </div>
                <h4 className="text-sm font-extrabold text-white font-sora">Why apps reject them</h4>
                <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                  The UPI specification supports addressing payees as <code className="text-red-400 font-mono text-[10.5px]">account@IFSC.ifsc.npci</code>, but major platforms like PhonePe and Paytm treat it as a high-risk "unverified payee" pattern and block the payment with security warnings. Google Pay and BHIM may still let it through after extra confirmations.
                </p>
              </div>

              {/* Column 2 */}
              <div className="bg-[#0E1528] border border-indigo-500/25 p-6 rounded-2xl space-y-3 shadow-md shadow-indigo-950/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-indigo-500 text-white text-[9px] font-bold px-2.5 py-1 rounded-bl-xl font-mono uppercase">Recommended</div>
                <div className="w-10 h-10 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl flex items-center justify-center text-sm font-black">
                  ✓
                </div>
                <h4 className="text-sm font-extrabold text-white font-sora">Use your UPI ID instead</h4>
                <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                  Every bank assigns you a UPI ID the moment you set up UPI on any compliant application (e.g., <code className="text-indigo-300 font-mono text-[10.5px]">name@okhdfc</code>, <code className="text-indigo-300 font-mono text-[10.5px]">9876543210@paytm</code>). It is the canonical NPCI addressing scheme and works beautifully in every app, every single time.
                </p>
              </div>

              {/* Column 3 */}
              <div className="bg-[#0E1528] border border-slate-850 p-6 rounded-2xl space-y-3">
                <div className="w-10 h-10 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl flex items-center justify-center text-sm font-black">
                  🔎
                </div>
                <h4 className="text-sm font-extrabold text-white font-sora">Don't know your UPI ID?</h4>
                <p className="text-[11.5px] text-slate-400 leading-relaxed font-sans">
                  Open any UPI app → Navigate to Profile → Copy Your UPI ID. Most Indian banking institutions also let you configure a custom human-readable identifier (like <code className="text-emerald-400 font-mono text-[10.5px]">yourbrand@hdfcbank</code>) instantly for free. It coordinates to the exact same underlying bank ledger.
                </p>
              </div>

            </div>
          </div>
        </section>

        {/* 8b. Highly Interactive Frequently Asked Questions Accordion Section */}
        <section id="faq-section" className="py-20 border-b border-slate-900/80 relative">
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-500/5 rounded-full blur-[140px] pointer-events-none"></div>

          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-14">
              <span className="text-xs bg-indigo-500/10 text-indigo-400 font-extrabold px-3 py-1.5 rounded-full border border-indigo-500/20 uppercase tracking-widest">
                Knowledge Base
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-4 font-sora tracking-tight">Frequently Asked Questions</h2>
              <p className="text-xs text-slate-400 mt-2 max-w-sm mx-auto">
                Got questions about ZuelPay? Expand the panels below for clear guidelines.
              </p>
            </div>

            {/* STATE-DRIVEN ACCORDION */}
            <div className="space-y-4">
              {[
                {
                  q: "How do I generate a UPI QR code?",
                  a: "Under the interactive sandbox workspace, enter your UPI ID, optional target amount, and invoice remarks. Our client-side rendering matrix generates standard consumer deep links and high-resolution vector QR standees instantly. You can copy the code or click download standalone JPG."
                },
                {
                  q: "What is a UPI ID (also called VPA)?",
                  a: "A Virtual Payment Address (VPA) is a unique email-like identifier (e.g., name@okaxis) assigned by your bank. It maps to your deep bank credentials (account number, IFSC), allowing payees to receive deposits instantly without exposing sensitive banking details during settlements."
                },
                {
                  q: "What does @okaxis, @okicici, @ybl, @paytm mean in a UPI ID?",
                  a: "These are Payment Service Provider (PSP) handles operated by Indian clearing banks. E.g., @okaxis is the Google Pay handle backed by Axis Bank, @ybl is the PhonePe handle backed by Yes Bank, and @paytm is operated by Paytm Payments Bank. These act as routing endpoints to coordinate NPCI database queries."
                },
                {
                  q: "Can I generate a UPI QR code with a fixed amount?",
                  a: "Yes! Defining a specific monetary sum locks the target amount within the dynamic BHIM UPI QR metadata. When a customer scans the standee, their banking application automatically pre-fills that exact sum and disables modification, guaranteeing error-free settlements."
                },
                {
                  q: "Can I generate a UPI QR code for a bank account (without a UPI ID)?",
                  a: "While the UPI scheme theoretically allows wrapping bank coordinates directly under custom wrappers (account@IFSC), most popular consumer platforms strictly block these requests today due to security risk compliance. We highly recommend configuring your standard active UPI ID instead."
                },
                {
                  q: "Is ZuelPay free? Are there any fees?",
                  a: "Yes! ZuelPay is a completely free, open-source tool. Since the deep links and QR parameters compile entirely on your device browser without routing transactions through intermediate processing servers, there are zero commission charges, 0% MDR, and zero fees."
                },
                {
                  q: "Will my QR code work in Google Pay, PhonePe, Paytm, BHIM and other UPI apps?",
                  a: "Absolutely! Every compiled link and generated QR vector complies 100% with the official NPCI (National Payments Corporation of India) standardized BHIM UPI communication protocol, ensuring global scanning interoperability."
                },
                {
                  q: "What's the difference between a UPI QR code and a UPI payment link?",
                  a: "A UPI payment link is a clickable deep schema URL (upi://pay?...) designed for checkout buttons on mobile screens. A UPI QR code is the visual scan-ready grid matrix representing that exact link, which is perfect for desktop checkout or physical checkout standees."
                },
                {
                  q: "Why is my payment app showing a security warning?",
                  a: "UPI banking apps occasionally flag direct peer-to-peer (P2P) transfers with a first-time payee warning to protect you against spoofing scams. This warning is a default banking notice and can be safely overridden. Bypassing third-party payment aggregators is safe because the payer sees your actual bank-verified name prior to typing their UPI PIN."
                }
              ].map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div 
                    key={idx}
                    className="bg-[#0E1528] border border-slate-850 rounded-2xl overflow-hidden transition-all duration-300"
                  >
                    <button
                      type="button"
                      onClick={() => setOpenFaq(isOpen ? null : idx)}
                      className="w-full px-6 py-4.5 text-left flex justify-between items-center bg-[#0E1528] hover:bg-slate-900/40 transition-colors"
                    >
                      <span className="text-xs sm:text-sm font-extrabold text-white font-sora pr-4">
                        {faq.q}
                      </span>
                      <span className={`text-[15px] font-black shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-45 text-blue-500' : 'text-slate-500'}`}>
                        ＋
                      </span>
                    </button>
                    
                    {/* Animated Expandable body panel */}
                    <div 
                      className={`transition-all duration-300 ease-in-out overflow-hidden ${isOpen ? 'max-h-[250px] border-t border-slate-900/60' : 'max-h-0'}`}
                    >
                      <div className="p-6 text-xs text-slate-350 leading-relaxed font-sans font-medium space-y-2 select-text">
                        <p>{faq.a}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* 8c. Onboarding portals (Taking regular business payments) & 8d. About UPI Info Panel Block */}
        <section className="py-20 bg-[#050810]/40 border-b border-slate-900/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              
              {/* 100% in-browser architecture benefit */}
              <div className="bg-[#0E1528] border border-slate-850 rounded-3xl p-8 space-y-6">
                <div>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-extrabold px-2.5 py-1 rounded-md uppercase tracking-wider border border-emerald-500/20">
                    Zero Servers · Zero Signups
                  </span>
                  <h3 className="text-lg font-bold text-white font-sora mt-3">100% In-Browser Architecture</h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Unlike traditional payment gateways that require corporate documents, KYC verifications, 2–3% transaction cuts, and complex server integrations, ZuelPay runs completely client-side in your web browser:
                  </p>
                </div>

                <div className="space-y-3.5 text-xs text-slate-350">
                  <div className="flex items-start gap-2.5">
                    <span className="text-emerald-400 font-bold shrink-0 mt-0.5">✓</span>
                    <p><strong>Zero Backend Servers:</strong> QR codes and payment deep links compile directly in your browser without transmitting any data over remote server APIs.</p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="text-emerald-400 font-bold shrink-0 mt-0.5">✓</span>
                    <p><strong>No Merchant Account Required:</strong> No signup forms, no contracts, and no approval waiting times. Open the app and start generating immediately.</p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="text-emerald-400 font-bold shrink-0 mt-0.5">✓</span>
                    <p><strong>Direct Account Settlement:</strong> Payments go straight into your bank account via your official bank UPI VPA with 0% commission fees.</p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="text-emerald-400 font-bold shrink-0 mt-0.5">✓</span>
                    <p><strong>Private Local Storage:</strong> Payee coordinates and logged transaction slips stay safely saved in your browser's localStorage.</p>
                  </div>
                </div>
              </div>

              {/* About UPI details */}
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold text-white font-sora">About UPI Protocol</h3>
                  <p className="text-[12.5px] text-slate-400 leading-relaxed mt-2">
                    UPI (Unified Payments Interface) is the real-time banking payment system built by NPCI (National Payments Corporation of India) that lets mobile apps move money peer-to-peer and personal/business transfers in a single, unified flow.
                  </p>
                </div>

                <div className="space-y-4">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider font-extrabold block">Newer additions since 2022:</span>
                  
                  <div className="space-y-3.5 text-xs text-slate-350">
                    <div className="flex items-start gap-2.5">
                      <span className="text-indigo-400 shrink-0 select-none">▶</span>
                      <p><strong>UPI Lite</strong> — on-device wallet container for lightning-fast small-value transfers without requiring PIN authorizations.</p>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <span className="text-indigo-400 shrink-0 select-none">▶</span>
                      <p><strong>UPI on RuPay Credit Card</strong> — seamlessly charge purchases to your credit line directly through UPI barcodes.</p>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <span className="text-indigo-400 shrink-0 select-none">▶</span>
                      <p><strong>UPI International</strong> — remit funds directly to global destinations in Singapore, UAE, France, Sri Lanka, Bhutan, Mauritius, and more.</p>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <span className="text-indigo-400 shrink-0 select-none">▶</span>
                      <p><strong>UPI Circle</strong> — secure delegative controls permitting secondary family members or staff to initiate transactions under primary oversight.</p>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <span className="text-indigo-400 shrink-0 select-none">▶</span>
                      <p><strong>Secondary UPI numbers</strong> — link multiple mobile handles and numerical aliases to one base savings bank catalog.</p>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </section>

        {/* 8e. Issue with a UPI payment? Redressal list block */}
        <section className="py-16 bg-[#070a14] border-b border-slate-900/80">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
            <h3 className="text-lg font-bold text-white font-sora">Issue with a UPI payment?</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-left">
              <div className="bg-[#0E1528] p-4.5 border border-slate-850 rounded-xl space-y-1.5">
                <span className="text-[10px] font-bold text-indigo-400 font-mono block">STAGE 01</span>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">Contact your banking institution first — they remain the official system of record for deposits.</p>
              </div>

              <div className="bg-[#0E1528] p-4.5 border border-slate-850 rounded-xl space-y-1.5">
                <span className="text-[10px] font-bold text-indigo-400 font-mono block">STAGE 02</span>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">For problems with specific UPI mobile apps, inspect NPCI's official list of third-party portals for support channels.</p>
              </div>

              <div className="bg-[#0E1528] p-4.5 border border-slate-850 rounded-xl space-y-1.5">
                <span className="text-[10px] font-bold text-indigo-400 font-mono block">STAGE 03</span>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">For unresolved transacting disputes, immediately file direct entries on the NPCI dispute redressal pipeline portal.</p>
              </div>

              <div className="bg-[#0E1528] p-4.5 border border-slate-850 rounded-xl space-y-1.5">
                <span className="text-[10px] font-bold text-indigo-400 font-mono block">STAGE 04</span>
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">To report a technical bug, system vulnerability, or platform misuse, contact our sandbox desk via email support.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 9. CTA Banner Section */}
        <section className="py-20 md:py-28 relative">
          
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-blue-600/10 rounded-full blur-[160px] pointer-events-none select-none"></div>

          <div className="max-w-4xl mx-auto px-4 text-center space-y-6 relative z-10">
            <h2 className="text-3xl md:text-4xl font-extrabold text-white font-sora tracking-tight">Ready to Simplify Direct UPI Settlements?</h2>
            <p className="text-slate-400 text-sm max-w-xl mx-auto font-sans leading-relaxed">
              Unlock free manual settlements control. Lock your private business coordinate identifiers and collect payments effortlessly.
            </p>
            <div className="flex justify-center pt-2">
              <button
                onClick={() => scrollToSection('interactive-workspace')}
                className="px-8 py-4 bg-blue-600 hover:bg-blue-550 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg flex items-center gap-2 cursor-pointer hover:scale-[1.01]"
              >
                <span>Start Direct Payment Workspace</span>
                <ArrowRight className="w-4 h-4 text-blue-200" />
              </button>
            </div>
          </div>
        </section>

      </div>

      {/* 10. SaaS Footer Frame: Multi links layout */}
      <footer className="bg-[#050810] border-t border-slate-900 py-12 md:py-16 text-xs text-slate-500 font-sans antialiased shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-900/60">
            
            <div className="space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 bg-gradient-to-tr from-blue-600 to-indigo-550 rounded-lg flex items-center justify-center">
                  <span className="text-white font-black text-sm select-none">Z</span>
                </div>
                <span className="font-extrabold text-sm text-white font-sora">ZuelPay</span>
              </div>
              <p className="text-[10px] text-slate-505 leading-relaxed max-w-xs">
                Zero PG integrations, Zero commission fee, Direct account-to-account UPI settlements platform with manual verification controls.
              </p>
            </div>

            <div>
              <h5 className="font-bold text-slate-350 uppercase tracking-widest text-[10px] mb-3 font-sora">Platform Tools</h5>
              <ul className="space-y-2 text-[11px]">
                <li><button onClick={() => scrollToSection('interactive-workspace')} className="hover:text-white transition-colors cursor-pointer text-left">Workspace QR Generator</button></li>
                <li><button onClick={() => setRoute('status')} className="hover:text-white transition-colors cursor-pointer text-left font-semibold text-blue-400">Track Payment Status</button></li>
                <li><button onClick={() => setRoute('payment')} className="hover:text-white transition-colors cursor-pointer text-left text-slate-350">Checkout Test Preview</button></li>
                <li>
                  <a 
                    href="https://www.instagram.com/finologicx/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="hover:text-pink-400 text-slate-350 transition-colors cursor-pointer text-left flex items-center gap-1 text-[11px] font-bold"
                  >
                    <Instagram className="w-3.5 h-3.5 text-pink-500 animate-pulse" />
                    <span>Follow @FINOLOGICX</span>
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-slate-350 uppercase tracking-widest text-[10px] mb-3 font-sora">Security Standards</h5>
              <ul className="space-y-2 text-[10px] leading-relaxed text-slate-500">
                <li>✓ No signups or token secrets hosted</li>
                <li>✓ Sandboxed browser Local Storage</li>
                <li>✓ Direct peer-to-peer VPA scheme</li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-slate-350 uppercase tracking-widest text-[10px] mb-3 font-sora">Help &amp; Support</h5>
              <ul className="space-y-2 text-[11px] text-slate-505">
                <li className="flex items-center gap-1.5 font-bold text-emerald-500">
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp Desk Active</span>
                </li>
                <li>Email Support: {settings.supportEmail || 'support@zuelpay.com'}</li>
              </ul>
            </div>

          </div>

          {/* Professional Regulatory & Security Disclaimer Banner for Visitors */}
          <div className="my-8 p-5 bg-[#080d19]/80 border border-slate-900/80 rounded-2xl text-[11px] leading-relaxed text-slate-400 space-y-3 shadow-inner">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900/60 pb-2">
              <div className="flex items-center gap-2 text-indigo-400 font-extrabold uppercase tracking-wider text-[10px]">
                <ShieldCheck className="w-4 h-4 text-indigo-500 animate-pulse" />
                <span>Regulatory Safety advisory &amp; operational Disclaimer</span>
              </div>
              <span className="text-[9px] text-slate-600 font-mono">ID: LUP-RECON-V34</span>
            </div>
            
            <p className="font-sans">
              <strong className="text-slate-300">Operational Notice:</strong> ZuelPay is a 100% in-browser, client-side utility designed to generate UPI payment QR codes and payment links directly on your device. This platform <strong className="text-emerald-400 font-extrabold">requires NO backend servers and NO merchant accounts</strong>. No transaction funds flow through any intermediary servers; transfers settle directly between payer and payee bank accounts.
            </p>
            
            <p className="text-[10px] text-slate-450 border-l-2 border-indigo-550/40 pl-3 italic">
              <strong className="text-amber-500 uppercase font-black not-italic tracking-wider">⚠️ CRITICAL REQUIREMENT FOR VISITORS:</strong> When executing payments via shown QR codes, payees must input the accurate 12-digit transaction UTR reference sequence (Bank Link ID) generated by their UPI application. Attempting to submit fraudulent, manipulated, or simulated records is strictly prohibited. All validation actions, browser user-agent tokens, and IP parameters are cryptographically logged in the security audit ledger.
            </p>

            <div className="border-t border-slate-900/60 pt-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-[10px] text-slate-500 font-mono">
              <span className="flex items-center gap-1.5"><Activity className="w-3.5 h-3.5 text-emerald-550" /> State Engine: Decentralized ledger matching is active</span>
              <a 
                href="https://www.instagram.com/finologicx/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 transition-all hover:translate-x-0.5"
              >
                <span>Insights by fintech partner: @FINOLOGICX</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] text-slate-600">
            <div className="flex flex-wrap gap-4 mt-2 sm:mt-0 select-none">
              <button onClick={() => setActivePolicyModal('terms')} className="hover:text-slate-300 transition-colors cursor-pointer font-bold">Terms of Service</button>
              <span className="text-slate-800">|</span>
              <button onClick={() => setActivePolicyModal('privacy')} className="hover:text-slate-300 transition-colors cursor-pointer font-bold">Privacy Policy</button>
              <span className="text-slate-800">|</span>
              <button onClick={() => setActivePolicyModal('refund')} className="hover:text-slate-300 transition-colors cursor-pointer font-bold">Refund Policy</button>
            </div>
            <span>© 2026 ZuelPay. All manual settlements ledger verification modules protected under open sandbox licensing.</span>
            <span className="flex items-center gap-1">Made with premium fintech care <Heart className="w-3 h-3 text-rose-500 fill-current" /></span>
          </div>

        </div>
      </footer>

      {/* 11. POLICY DOCUMENT OVERLAYS (T&C, PRIVACY, REFUNDS) */}
      {activePolicyModal && (
        <div id="policy-overlay-modal" className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0E1528] border border-slate-850 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl relative animate-fade-in max-h-[85vh] flex flex-col">
            
            {/* Header */}
            <div className="p-6 border-b border-slate-800 flex items-center justify-between sticky top-0 bg-[#0E1528] z-10">
              <div className="flex items-center gap-2">
                <span className="text-blue-500">📜</span>
                <span className="font-extrabold text-xs sm:text-sm text-white uppercase tracking-wider font-sora">
                  {activePolicyModal === 'terms' && 'ZuelPay | Terms & Conditions'}
                  {activePolicyModal === 'privacy' && 'ZuelPay | Privacy Policy'}
                  {activePolicyModal === 'refund' && 'ZuelPay | Refund & Cancellation Guidelines'}
                </span>
              </div>
              <button 
                onClick={() => setActivePolicyModal(null)}
                className="p-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white rounded-lg transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content body */}
            <div className="p-6 overflow-y-auto text-xs text-slate-300 leading-relaxed space-y-4 font-sans select-text">
              {activePolicyModal === 'terms' && (
                <>
                  <p className="text-slate-450 italic">Last Revised: June 2026</p>
                  <p>Welcome to ZuelPay. Please read these Terms and Conditions carefully before generating or routing payments. By accessing or using our open sandbox-licensed utilities, you agree to form a binding agreement under these terms.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">1. Direct-to-VPA Payment Architecture</h4>
                  <p>ZuelPay does NOT operate payment pooling servers, digital escrow balances, banking ledgers, or payment orchestration gateways. ZuelPay is on-device compile software. All transactions generated compile directly to the peer-to-peer VPA protocols (Unified Payments Interface) on the client side.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">2. Zero Commission Fee Clause</h4>
                  <p>Because ZuelPay does not act as an intermediary payment processor, we charge a strict zero-percent commission fee on settlement logs. You retain 100% of all generated receipts. No hidden platform charges apply.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">3. Accuracy of Payee Routing Parameters</h4>
                  <p>The payee has sole, autonomous responsibility for specifying precise UPI identifiers (VPA handles) and business identities. ZuelPay does not screen, validate, or endorse individual VPA IDs on bank rails. If any coordinates are typed incorrectly by a user, funds may be misrouted. ZuelPay assumes zero liability for such configuration errors.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">4. Manual Ledger Verification Accountability</h4>
                  <p>The Admin live screen utilizes local sandboxed caches to monitor client-submitted UTR 12-digit reference codes. All reconciliation checks are manually done on-site by matching against your official corporate bank statements. Approving or rejecting matching ledger rows remains a core administrative responsibility of the account holder.</p>
                </>
              )}

              {activePolicyModal === 'privacy' && (
                <>
                  <p className="text-slate-450 italic">Last Revised: June 2026</p>
                  <p>At ZuelPay, we respect your privacy. This document outlines our data sandbox protocols.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">1. No Sovereign Database Hosting</h4>
                  <p>ZuelPay operates purely inside your local browser storage using sandboxed frameworks (indexedDB / localStorage). We do not operate remote databases or cloud servers to store your customer details, corporate secrets, login credentials, transaction hashes, or bills.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">2. Customer Payment Coordinates</h4>
                  <p>When a client checks out, their name, support WhatsApp, email, transaction receipts, and 12-digit UTR identifiers are committed strictly inside the user's local browser storage cache. This client telemetry is shared with no third-party APIs or corporate marketing layers.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">3. Device Protection</h4>
                  <p>Because all payment tables, settings parameters, and short link counters reside inside your sandboxed web assets, clearing your secure browser cookies or local data caches will completely wipe out your records. Ensure periodic report generation or download statements to back up your billing ledger.</p>
                </>
              )}

              {activePolicyModal === 'refund' && (
                <>
                  <p className="text-slate-450 italic">Last Revised: June 2026</p>
                  <p>This policy outlines constraints relating to transaction disputes and settlement actions.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">1. Direct Settlement Claims</h4>
                  <p>Because ZuelPay does not orchestrate intermediate payment flows, we have zero access to the financial funds transferred during checkouts. No monetary balances ever flow through ZuelPay pools. Consequently, ZuelPay cannot issue chargebacks, wire transfers, currency refunds, or settlement cancellations.</p>
                  
                  <h4 className="font-extrabold text-sm text-white font-sora mt-4">2. Payee-to-Payer Settlement Support</h4>
                  <p>If a customer is duplicate billed or files a disputable transaction claim, the settlement must be resolved directly with the payee. Payer must email or WhatsApp the payee's support coordinates with the corresponding 12-digit bank statement UTR code to secure direct refund adjustments.</p>
                </>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 bg-[#0A0D18] flex justify-end shrink-0">
              <button 
                onClick={() => setActivePolicyModal(null)}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-550 text-white rounded-xl text-xs font-extrabold uppercase tracking-wider transition-colors cursor-pointer"
              >
                I Understand &amp; Agree
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Dynamic Floating Toast Feedback Notifications */}
      {toastMessage && (
        <div id="floating-feedback-toast" className="fixed bottom-6 right-6 z-[150] bg-slate-900 border border-indigo-500 text-indigo-300 font-bold px-4 py-3.5 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs animate-bounce animate-fade-in">
          <span className="text-indigo-400 text-sm">⚡</span>
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
