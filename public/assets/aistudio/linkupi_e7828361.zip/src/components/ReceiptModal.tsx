/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Payment, BusinessSettings } from '../types';
import { db } from '../services/db';
import { X, Printer, Check, Copy } from 'lucide-react';

interface ReceiptModalProps {
  payment: Payment;
  onClose: () => void;
  settings?: BusinessSettings;
}

// Indian Rupee number to words converter
export function numberToWords(num: number): string {
  if (num === 0) return 'Zero';
  
  const single = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'
  ];
  const double = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  
  function convertLessThanThousand(n: number): string {
    let internalStr = '';
    if (n >= 100) {
      internalStr += single[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    if (n > 0) {
      if (internalStr !== '') internalStr += 'and ';
      if (n < 20) {
        internalStr += single[n];
      } else {
        internalStr += double[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + single[n % 10] : '');
      }
    }
    return internalStr.trim();
  }
  
  const integerPart = Math.floor(num);
  const paise = Math.round((num - integerPart) * 100);
  
  let result = '';
  
  if (integerPart >= 10000000) {
    const crores = Math.floor(integerPart / 10000000);
    result += convertLessThanThousand(crores) + ' Crore ';
  }
  
  const lakhVal = Math.floor((integerPart % 10000000) / 100000);
  if (lakhVal > 0) {
    result += convertLessThanThousand(lakhVal) + ' Lakh ';
  }
  
  const thousandVal = Math.floor((integerPart % 100000) / 1000);
  if (thousandVal > 0) {
    result += convertLessThanThousand(thousandVal) + ' Thousand ';
  }
  
  const restVal = integerPart % 1000;
  if (restVal > 0) {
    if (result !== '' && restVal < 100) result += 'and ';
    result += convertLessThanThousand(restVal) + ' ';
  }
  
  result = result.trim() + ' Rupees';
  
  if (paise > 0) {
    result += ' and ' + convertLessThanThousand(paise) + ' Paise';
  }
  
  return result + ' Only';
}

export default function ReceiptModal({ payment, onClose, settings: propSettings }: ReceiptModalProps) {
  const settings = propSettings || db.getSettings();
  const allPayments = db.getPayments();
  const [copied, setCopied] = React.useState(false);

  // Generate dynamic stable sequential serial number
  const verifiedPaymentsChronological = [...allPayments]
    .filter(p => p.status === 'verified')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  const index = verifiedPaymentsChronological.findIndex(p => p.id === payment.id);
  const serialIndex = index !== -1 ? index + 1 : 1;
  const yearSuffix = new Date(payment.date).getFullYear();
  const sequenceSerial = `REC-${yearSuffix}-${String(serialIndex).padStart(4, '0')}`;
  const serialNo = payment.receiptNo || sequenceSerial;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    const recText = `🧾 OFFICIAL RECEIPT: ${settings.businessName}
Serial Number: ${serialNo}
Amount Received: ₹${payment.amount.toLocaleString('en-IN')}.00
Date: ${new Date(payment.date).toLocaleDateString()}
UTR Number: ${payment.utrNumber}
Reconciliation Status: VERIFIED & SETTLED SUCCESSFULLY

Generated online via Secure Gateway.`;
    navigator.clipboard.writeText(recText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getDisplayMonth = () => {
    const d = new Date(payment.date);
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return `${months[d.getMonth()].toUpperCase()} ${d.getFullYear()}`;
  };

  const getDisplayReason = () => {
    return payment.adminNote || 'Monthly Subscription Plan Fee';
  };

  return (
    <div 
      id="receipt-modal-overlay" 
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      className="fixed inset-0 z-[100] bg-slate-950/85 backdrop-blur-sm flex justify-center items-start p-4 py-8 overflow-y-auto print:bg-white print:p-0 cursor-zoom-out animate-fadeIn"
    >
      
      {/* Receipt Dialog Box */}
      <div 
        className="bg-slate-900 border border-slate-800 text-slate-905 rounded-3xl w-full max-w-xl shadow-2xl flex flex-col overflow-hidden md:my-6 print:shadow-none print:border-none print:w-full print:max-w-none print:my-0 cursor-default"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Modal Toolbar (hidden on print) */}
        <div className="bg-slate-950 border-b border-slate-800 px-5 py-4 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-xs font-black uppercase text-indigo-400 tracking-wider font-mono">Receipt Invoice Viewer</span>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              title="Copy Summary Text"
              className="p-1.5 px-2.5 text-slate-400 hover:text-white hover:bg-slate-850 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold font-mono border border-slate-800/60"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
            
            <button
              onClick={handlePrint}
              className="p-1.5 px-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold font-mono shadow-md"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            
            <button
              onClick={onClose}
              title="Close Receipt"
              className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 rounded-xl transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PRINT CONTAINER WRAPPER - Redesigned to render matching the dashboard receipt preview style */}
        <div className="p-6 sm:p-8 bg-slate-900 print:p-0 print:bg-white flex-grow">
          
          {/* Visual thermal/invoice container */}
          <div className="bg-white text-slate-900 p-8 rounded-2xl shadow-inner font-mono text-xs border border-slate-300 relative select-all leading-normal">
            
            {/* Top physical rolling cut outline */}
            <div className="border-t-4 border-dashed border-slate-350 pt-4 text-center space-y-1">
              <h4 className="font-sans font-black text-base text-slate-950 tracking-tight uppercase">
                {settings.businessName || 'AUTHORIZED UPI PAYEE'}
              </h4>
              <p className="text-[10px] text-slate-500 font-sans tracking-tight">
                {settings.address || 'Official UPI Settle Desk'}
              </p>
              <p className="text-[9px] text-slate-400 leading-none">
                Support Contact: {settings.whatsappNumber ? `+${settings.whatsappNumber.replace(/[^0-9]/g, '')}` : 'Direct Portal'}{settings.supportEmail ? ` | ${settings.supportEmail}` : ''}
              </p>
            </div>

            {/* Dividers */}
            <div className="py-3 border-b-2 border-dashed border-slate-900 text-center text-[10px] font-bold">
              CASH RECEIPTS &amp; BILL MEMO
            </div>

            {/* Transaction metadata */}
            <div className="py-3 space-y-1.5 border-b border-slate-300">
              <div className="flex justify-between">
                <span>RECEIPT CODE:</span>
                <span className="font-extrabold">{serialNo}</span>
              </div>
              <div className="flex justify-between">
                <span>SETTLE DATE:</span>
                <span className="font-bold">{new Date(payment.date).toLocaleString('en-IN', { dateStyle: 'short' })}</span>
              </div>
              <div className="flex justify-between">
                <span>PAY METHOD:</span>
                <span className="font-bold uppercase">UPI Settled</span>
              </div>
              {payment.utrNumber && (
                <div className="flex justify-between">
                  <span>UTR REFERRER:</span>
                  <span className="font-bold uppercase select-all text-xs font-sans text-purple-700 bg-purple-50 px-1 rounded border border-purple-100">{payment.utrNumber}</span>
                </div>
              )}
            </div>

            {/* Customer billing address */}
            <div className="py-3 space-y-1 border-b border-slate-300">
              <div className="text-[9px] text-slate-550 uppercase tracking-wider font-sans font-bold">Bill To Client:</div>
              <div className="flex justify-between">
                <span className="font-bold">CLIENT NAME:</span>
                <span className="font-extrabold uppercase">{payment.customerName || 'Walker Guest Account'}</span>
              </div>
              <div className="flex justify-between">
                <span>CLIENT MOBILE:</span>
                <span className="font-bold">+{payment.mobile || '---'}</span>
              </div>
              {payment.email && (
                <div className="flex justify-between">
                  <span>CLIENT EMAIL:</span>
                  <span className="font-bold lowercase text-slate-500">{payment.email}</span>
                </div>
              )}
            </div>

            {/* Billing Period & Purpose */}
            <div className="py-2.5 px-3 bg-purple-50/50 border border-purple-100/60 rounded-xl my-2 space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-500 font-bold">BILLING MONTH:</span>
                <span className="font-black text-purple-700 uppercase">{getDisplayMonth()}</span>
              </div>
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-500 font-bold">COLLECT PURPOSE:</span>
                <span className="font-bold text-slate-800 text-right max-w-[280px] truncate" title={getDisplayReason()}>{getDisplayReason()}</span>
              </div>
            </div>

            {/* Items table */}
            <div className="py-4 space-y-3 border-b-2 border-dashed border-slate-900">
              <div className="grid grid-cols-12 text-[10px] font-bold text-slate-500 uppercase">
                <span className="col-span-6">DESCRIPTION</span>
                <span className="col-span-2 text-center">QTY</span>
                <span className="col-span-4 text-right">AMOUNT (₹)</span>
              </div>

              {/* Line dividers */}
              <div className="border-t border-slate-200 my-1"></div>

              <div className="space-y-2">
                <div className="grid grid-cols-12 text-[11px] leading-tight">
                  <span className="col-span-6 truncate font-sans text-slate-705">{getDisplayReason()}</span>
                  <span className="col-span-2 text-center">1</span>
                  <span className="col-span-4 text-right font-bold">₹{payment.amount.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Financial calculus */}
            <div className="py-4 space-y-2 text-right">
              <div className="space-y-1.5 max-w-[280px] ml-auto">
                <div className="flex justify-between text-slate-600 text-[11px]">
                  <span>SUB-TOTAL:</span>
                  <span className="font-semibold text-slate-800">₹{payment.amount.toFixed(2)}</span>
                </div>
                <div className="border-t border-slate-200 my-1"></div>
                <div className="flex justify-between font-sans text-sm font-black text-slate-950">
                  <span>NET TRANSACTION TOTAL:</span>
                  <span className="text-base font-black">₹{payment.amount.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Amount In Words Section */}
            <div className="p-3 bg-[#f8fafc] border border-slate-200 rounded-xl space-y-0.5 my-3">
              <span className="text-[8px] font-bold text-slate-450 uppercase tracking-widest block">Total Amount in Words</span>
              <p className="text-[10.5px] font-extrabold italic text-slate-800">{numberToWords(payment.amount)}</p>
            </div>

            {/* Dynamic Status & Seal Validation block */}
            <div className="pt-4 border-t border-slate-200 text-center space-y-4">
              
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-50 p-3 rounded-xl border border-slate-200/60">
                {/* Left: Beautiful Round Verification Stamp */}
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full border-4 border-dashed border-emerald-600/35 flex items-center justify-center p-0.5 rotate-[12deg] flex-shrink-0">
                    <div className="w-full h-full rounded-full border border-emerald-600 border-solid flex flex-col items-center justify-center bg-emerald-50 text-[6px] font-black text-emerald-800 uppercase leading-none text-center">
                      <span>ZuelPay</span>
                      <span className="text-[5.5px] tracking-tighter block text-emerald-600 mt-0.5">VERIFIED</span>
                      <span className="text-[4px] block">PAID</span>
                    </div>
                  </div>
                  <div className="text-left space-y-0.5">
                    <span className="text-[10px] font-sans font-extrabold text-emerald-700 flex items-center gap-1 uppercase tracking-wider leading-none">
                      ✓ Verified Settle
                    </span>
                    <span className="text-[8px] text-slate-500 block font-mono">Status: SECURED P2P SETTLEMENT</span>
                    <span className="text-[7.5px] text-slate-450 block font-mono">Digital Token: REC-{serialNo.replace(/\//g, '')}</span>
                  </div>
                </div>

                {/* Right: Validation QR Code Box */}
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-white rounded-lg border border-slate-205 flex-shrink-0 flex items-center justify-center shadow-inner">
                    <svg className="w-9 h-9 text-slate-850" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <rect x="2" y="2" width="6" height="6" rx="0.5" />
                      <rect x="16" y="2" width="6" height="6" rx="0.5" />
                      <rect x="2" y="16" width="6" height="6" rx="0.5" />
                      <rect x="14" y="14" width="4" height="4" />
                      <path d="M10 2h4M2 10h4M16 10h6M10 16h2M14 20h8" />
                    </svg>
                  </div>
                  <div className="text-left hidden md:block">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block leading-tight">Digital Slip code</span>
                    <span className="text-[7.5px] text-slate-400 block font-mono max-w-[120px] truncate">{serialNo}</span>
                  </div>
                </div>
              </div>

              {/* Signature section if signatureImage is uploaded */}
              {settings.signatureImage && (
                <div className="flex flex-col items-end pt-2 pr-2">
                  <img 
                    src={settings.signatureImage} 
                    alt="authorised-signature" 
                    className="h-9 max-w-[110px] object-contain" 
                    referrerPolicy="no-referrer"
                  />
                  <div className="border-t border-slate-200 mt-1 w-24 text-right pt-0.5">
                    <span className="text-[7.5px] font-bold uppercase tracking-wider text-slate-400 block leading-none">Authorised Sign</span>
                  </div>
                </div>
              )}

              <div className="text-[8.5px] font-sans font-bold tracking-tight uppercase text-slate-450 text-center block">
                Authorized digital bill memo receipt • Generated via ZuelPay Portal
              </div>
              <div className="text-[8px] italic text-slate-450 mt-1 pb-1">
                ~~ Thank you for your support and business partnership patronage ~~
              </div>
            </div>

          </div>

        </div>

        {/* Bottom Bar Controls for Better Usability (hidden on print) */}
        <div className="bg-slate-950 border-t border-slate-850 px-5 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 print:hidden">
          <span className="text-[10px] text-slate-500 font-mono">
            Digital ID: LU-SEC-{payment.utrNumber.slice(-4)}-VERIFIED
          </span>
          
          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={handlePrint}
              className="flex-1 sm:flex-none px-4 py-2 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-200 text-xs font-bold uppercase font-mono rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
            >
              <Printer className="w-4 h-4" />
              Print Receipt
            </button>
            
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2 bg-rose-950/40 text-rose-300 hover:bg-rose-900 hover:text-white border border-rose-955/20 text-xs font-bold uppercase font-mono rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              <X className="w-4 h-4" />
              Close Receipt
            </button>
          </div>
        </div>

      </div>
      
      {/* Standard CSS injection to override print controls perfectly */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #receipt-modal-overlay, #receipt-modal-overlay * {
            visibility: visible;
          }
          #receipt-modal-overlay {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: auto;
            background: white !important;
            padding: 0 !important;
            margin: 0 !important;
            box-shadow: none !important;
            backdrop-filter: none !important;
          }
          .print\\:hidden {
            display: none !important;
          }
          .print\\:border-none {
            border: none !important;
          }
          .print\\:p-0 {
            padding: 0 !important;
          }
          .print\\:bg-white {
            background: white !important;
          }
          .print\\:shadow-none {
            box-shadow: none !important;
          }
          /* Ensure modal occupies whole printable target screen */
          #receipt-modal-overlay > div {
            border: none !important;
            box-shadow: none !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            max-width: none !important;
          }
        }
      `}</style>

    </div>
  );
}
