/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from 'react';
import { ArrowUp } from 'lucide-react';

interface FintechEffectsWrapperProps {
  route: string;
  children: React.ReactNode;
}

export default function FintechEffectsWrapper({ route, children }: FintechEffectsWrapperProps) {
  // 1. YouTube-like Top Loading Bar State
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [visibleLoading, setVisibleLoading] = useState(false);

  useEffect(() => {
    // Trigger progress loading anim on route change
    setVisibleLoading(true);
    setLoadingProgress(15);
    
    const t1 = setTimeout(() => {
      setLoadingProgress(45);
    }, 100);

    const t2 = setTimeout(() => {
      setLoadingProgress(85);
    }, 350);

    const t3 = setTimeout(() => {
      setLoadingProgress(100);
      const t4 = setTimeout(() => {
        setVisibleLoading(false);
      }, 250);
      return () => clearTimeout(t4);
    }, 600);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [route]);

  // 2. Mouse Glow Effect State (Following Cursor)
  const [mousePos, setMousePos] = useState({ x: -100, y: -100 });
  const [isHoveringInteractive, setIsHoveringInteractive] = useState(false);
  const [isMobile, setIsMobile] = useState(true);

  useEffect(() => {
    // Check if mobile screen size to selectively disable heavier animations
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  // 3. Scroll Top Circular Progress State
  const [scrollPercent, setScrollPercent] = useState(0);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (docHeight <= 0) {
        setScrollPercent(0);
        setShowScrollTop(false);
        return;
      }
      const pct = Math.min(Math.max((scrollY / docHeight) * 100, 0), 100);
      setScrollPercent(Math.round(pct));
      setShowScrollTop(scrollY > window.innerHeight * 0.1); // After 10% viewport height
    };

    window.addEventListener('scroll', handleScroll);
    // Initial check
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // 4. Background Particle Dot-Line Canvas Logic
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Limit particles counts on mobile/tablet vs desktop
    const particleCount = isMobile ? 18 : 60;
    const connectionRadius = isMobile ? 80 : 130;
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
    }> = [];

    // Create particles initial points
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        radius: Math.random() * 1.5 + 1,
      });
    }

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      // Render connected mesh-web
      for (let i = 0; i < particles.length; i++) {
        const p1 = particles[i];
        p1.x += p1.vx;
        p1.y += p1.vy;

        // Bounce boundaries
        if (p1.x < 0 || p1.x > width) p1.vx *= -1;
        if (p1.y < 0 || p1.y > height) p1.vy *= -1;

        // Draw particle node
        ctx.beginPath();
        ctx.arc(p1.x, p1.y, p1.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(37, 99, 235, 0.15)'; // Blue subtle opacity
        ctx.fill();

        // Check distance to link lines
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < connectionRadius) {
            const alpha = (1 - dist / connectionRadius) * 0.08;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            // Gradient lines
            ctx.strokeStyle = `rgba(37, 99, 235, ${alpha})`;
            ctx.lineWidth = 0.65;
            ctx.stroke();
          }
        }
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [isMobile]);

  // Math variables for circle progress SVG
  const radius = 20;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (scrollPercent / 100) * circumference;

  return (
    <div className="relative min-h-screen SelectionMode select-auto overflow-hidden">
      
      {/* 1. YouTube-like Top Progress Line Bar */}
      {visibleLoading && (
        <div 
          className="fixed top-0 left-0 h-[3.5px] bg-gradient-to-r from-blue-600 via-indigo-500 to-[#10B981] z-[9999] transition-all duration-150 ease-out shadow-[0_0_10px_#2563eb]"
          style={{ width: `${loadingProgress}%` }}
        />
      )}

      {/* 2. Interactive Ambient Particles Background */}
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none select-none z-0 opacity-80"
        style={{ mixBlendMode: 'screen' }}
      />

      {/* 3. Mouse Following Radiant Aura Glow (Desktop Only) */}
      {!isMobile && (
        <div
          className="fixed w-[320px] h-[320px] rounded-full pointer-events-none select-none z-10 opacity-30 blur-[100px] transition-transform duration-200 ease-out"
          style={{
            left: `${mousePos.x - 160}px`,
            top: `${mousePos.y - 160}px`,
            background: 'radial-gradient(circle, rgba(37, 99, 235, 0.45) 0%, rgba(16, 185, 129, 0.2) 60%, transparent 100%)',
            mixBlendMode: 'screen'
          }}
        />
      )}

      {/* 4. Page Wrap Container */}
      <div className="relative z-20">
        {children}
      </div>

      {/* 5. Scroll-To-Top Circular Widget */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          type="button"
          className="fixed bottom-6 right-6 w-14 h-14 bg-[#0F172A]/85 backdrop-blur-md rounded-full border border-slate-700/60 shadow-xl shadow-black/40 z-50 flex items-center justify-center hover:scale-[1.08] active:scale-95 transition-all outline-none focus:ring-2 focus:ring-blue-500/50 cursor-pointer group"
          title="Scroll smoothly back to top"
        >
          {/* Circular progress SVG ring */}
          <svg className="w-full h-full transform -rotate-90 absolute top-0 left-0">
            <circle
              cx="28"
              cy="28"
              r={radius}
              className="stroke-slate-800/80 fill-none"
              strokeWidth="2.5"
            />
            <circle
              cx="28"
              cy="28"
              r={radius}
              className="stroke-blue-550 fill-none transition-all duration-300"
              strokeWidth="2.5"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
            />
          </svg>

          {/* Centered content with tooltip micro-interaction */}
          <div className="z-10 flex flex-col items-center justify-center pt-0.5">
            <ArrowUp className="w-4.5 h-4.5 text-slate-200 group-hover:text-white transition-colors group-hover:-translate-y-0.5 duration-300" />
            <span className="text-[8.5px] font-black text-slate-400 font-mono tracking-tighter leading-none mt-0.5">
              {scrollPercent}%
            </span>
          </div>
        </button>
      )}

    </div>
  );
}

// Global 3D Interactive Card helper
export function TiltCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const xc = rect.width / 2;
    const yc = rect.height / 2;

    // Subtly tilts cards for high depth quality
    const tiltX = -(y - yc) / 16;
    const tiltY = (x - xc) / 16;

    card.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(1.015, 1.015, 1.015)`;
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (!card) return;
    card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`${className} transition-all duration-200 ease-out`}
      style={{ transformStyle: 'preserve-3d' }}
    >
      {children}
    </div>
  );
}

// Global Magnetic Button controller
interface MagneticButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
}

export function MagneticButton({ children, className = '', ...props }: MagneticButtonProps) {
  const btnRef = useRef<HTMLButtonElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    const btn = btnRef.current;
    if (!btn) return;
    const rect = btn.getBoundingClientRect();

    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;

    const moveX = x * 0.18;
    const moveY = y * 0.18;

    btn.style.transform = `translate3d(${moveX}px, ${moveY}px, 0px) scale(1.02)`;
  };

  const handleMouseLeave = () => {
    const btn = btnRef.current;
    if (!btn) return;
    btn.style.transform = 'translate3d(0px, 0px, 0px) scale(1)';
  };

  return (
    <button
      ref={btnRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={className}
      style={{ transition: 'transform 0.2s cubic-bezier(0.25, 1, 0.5, 1)' }}
      {...props}
    >
      {children}
    </button>
  );
}
