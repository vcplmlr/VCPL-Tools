/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { db } from '../services/db';
import { BusinessSettings } from '../types';
import QRCodeGenerator from './QRCodeGenerator';
import { 
  Lock, 
  Sparkles, 
  ArrowLeft, 
  Smartphone, 
  User, 
  Mail, 
  FileText, 
  CheckCircle2, 
  Upload,
  Info,
  X,
  Send,
  ShieldCheck,
  Coins,
  Instagram
} from 'lucide-react';
import { TiltCard } from './FintechEffectsWrapper';

interface CustomerPaymentProps {
  settings: BusinessSettings;
  setRoute: (route: 'landing' | 'payment' | 'status' | 'admin') => void;
  setSubmittedMobile: (mobile: string) => void;
  setSubmittedUtr: (utr: string) => void;
  prefilledAmount?: number;
  prefilledRemarks?: string;
  prefilledPhone?: string;
}

export default function CustomerPayment({ 
  settings, 
  setRoute, 
  setSubmittedMobile, 
  setSubmittedUtr,
  prefilledAmount,
  prefilledRemarks,
  prefilledPhone
}: CustomerPaymentProps) {
  // Form states
  const [amount, setAmount] = useState<number | ''>(prefilledAmount || '');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState(prefilledPhone || '');
  const [email, setEmail] = useState('');
  const [utr, setUtr] = useState('');
  const [screenshot, setScreenshot] = useState<string>(''); // Base64 representation
  const [fileName, setFileName] = useState('');
  
  // Status feedback states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [validationError, setValidationError] = useState('');

  // Handle file upload preview converter
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
         setValidationError('File size should not exceed 2MB');
         return;
      }
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setScreenshot(reader.result as string);
        setValidationError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const clearScreenshot = () => {
    setScreenshot('');
    setFileName('');
  };

  // Submit trigger
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');

    // Field audits
    if (!name.trim()) return setValidationError('Please enter your full name');
    
    const cleanMobile = mobile.replace(/[^0-9]/g, '');
    if (cleanMobile.length < 10 || cleanMobile.length > 12) {
      return setValidationError('Please specify a valid 10-12 digit mobile number');
    }

    const cleanUtr = utr.trim().replace(/[^0-9]/g, '');
    if (cleanUtr.length !== 12) {
      return setValidationError('UPI UTR / Transaction ID must be exactly 12 numerical digits.');
    }

    if (!amount || amount <= 0) return setValidationError('Please specify a valid payment amount');

    setIsSubmitting(true);

    // Simulated short server delay for aesthetics
    setTimeout(() => {
      try {
        db.submitPayment({
          customerName: name.trim(),
          mobile: cleanMobile,
          email: email.trim() || undefined,
          amount: amount,
          utrNumber: cleanUtr,
          screenshot: screenshot || undefined,
          adminNote: prefilledRemarks ? `Purpose: ${prefilledRemarks}` : 'Waiting for bank statement sync'
        });

        setSubmittedMobile(cleanMobile);
        setSubmittedUtr(cleanUtr);
        setIsSuccess(true);
      } catch (err: any) {
        setValidationError('Fatal database error, please retry: ' + err.message);
      } finally {
        setIsSubmitting(false);
      }
    }, 1200);
  };

  if (isSuccess) {
    return (
      <div id="payment-success-view" className="min-h-screen bg-[#020617] text-white flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden">
        
        {/* Interactive background ambient light spots */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none select-none"></div>

        <div className="max-w-md w-full bg-slate-900/40 backdrop-blur-xl border border-emerald-500/20 rounded-3xl p-8 text-center shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative overflow-hidden">
          
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-teal-400"></div>

          <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-center text-emerald-450 mx-auto mb-6 shadow-lg animate-bounce">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full font-bold tracking-widest">
            Receipt Submitted
          </span>

          <h1 className="text-2xl font-black text-white mt-4 tracking-tight font-sora">Payment Settle Pending</h1>
          
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Your manual UPI reference <span className="font-mono font-bold text-teal-400">{utr}</span> is logged. A checkout auditor at <span className="font-semibold text-white">{settings.businessName}</span> will reconcile with raw bank Statements.
          </p>

          <div className="mt-6 p-4 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-2.5 text-left text-xs">
            <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
              <span className="text-slate-550 font-medium">Customer Name</span>
              <span className="text-white font-bold">{name}</span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
              <span className="text-slate-550 font-medium">UTR Reference / Ref ID</span>
              <span className="text-indigo-400 font-mono font-bold">{utr}</span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
              <span className="text-slate-550 font-medium">Transferred Amount</span>
              <span className="text-emerald-450 font-extrabold text-sm">₹{amount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-550 font-medium">Search Key (Mobile)</span>
              <span className="text-slate-350 font-mono">{mobile}</span>
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3">
            <button
              onClick={() => setRoute('landing')}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-550 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-blue-500/10 flex items-center justify-center gap-2 cursor-pointer active:scale-98 animate-pulse"
            >
              <span>Back to Home Screen</span>
            </button>
            
            <button
              onClick={() => {
                setIsSuccess(false);
                setName('');
                setMobile('');
                setEmail('');
                setUtr('');
                clearScreenshot();
              }}
              className="w-full py-3 bg-slate-900 border border-slate-800 hover:bg-slate-850 hover:border-slate-700 text-slate-300 font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer"
            >
              Submit another payment
            </button>
          </div>

          <p className="text-[9px] text-slate-500 mt-6 flex items-center justify-center gap-1.5">
            <Lock className="w-3 text-slate-600" />
            Protected by bank statement cryptographic matching logic
          </p>

        </div>
      </div>
    );
  }

  return (
    <div id="customer-payment-page" className="min-h-screen bg-[#020617] text-white font-sans selection:bg-blue-500 selection:text-white relative pb-16">
      
      {/* Dynamic background lighting */}
      <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-blue-600/5 rounded-full blur-[140px] pointer-events-none select-none"></div>
      <div className="absolute bottom-1/4 left-10 w-[300px] h-[300px] bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none select-none"></div>

      {/* Styled Sticky Navigation Bar */}
      <nav className="bg-slate-950/40 backdrop-blur-xl border-b border-slate-900 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <button
            onClick={() => setRoute('landing')}
            className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-widest text-slate-400 hover:text-white transition-colors cursor-pointer group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
            <span>Abandon Checkout</span>
          </button>

          <div className="text-center font-black text-sm tracking-tight font-sora flex items-center gap-1.5">
            <div className="w-6 h-6 bg-blue-600 rounded-md flex items-center justify-center text-white text-xs select-none">Z</div>
            <span>Zuel<span className="text-blue-500">Pay</span> Checkout</span>
          </div>

          <a
            href="https://www.instagram.com/finologicx/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[10px] bg-gradient-to-r from-pink-500/10 via-rose-500/5 to-transparent hover:from-pink-500/20 border border-pink-500/25 px-4 py-2 rounded-xl font-extrabold uppercase tracking-widest text-pink-300 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Instagram className="w-3.5 h-3.5 text-pink-400" />
            <span className="hidden sm:inline">Follow @FINOLOGICX</span>
            <span className="sm:hidden">Follow</span>
          </a>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-4 py-8 md:py-12 relative z-10">
        
        {/* Checkout Header Banner */}
        <div className="bg-gradient-to-tr from-[#0F172A]/70 via-[#0E1324]/70 to-[#1E1B4B]/30 backdrop-blur-xl border border-slate-850/60 rounded-3xl p-6 md:p-8 shadow-2xl mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
          
          <div className="absolute top-0 right-0 -m-16 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[9px] font-extrabold uppercase tracking-widest rounded-md">
              <span className="w-1.5 h-1.5 bg-emerald-450 rounded-full animate-ping" />
              Direct Account-to-Account Transfer
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white font-sora tracking-tight">
              Pay <span className="bg-gradient-to-r from-blue-400 to-indigo-350 bg-clip-text text-transparent">{settings.businessName}</span>
            </h1>
            <p className="text-xs text-slate-400 max-w-lg leading-relaxed">
              Scan the visual QR using your phone's camera, pay inside any standard UPI payment client, and submit your 12-digit bank UTR receipt key below.
            </p>
          </div>
          
          <div className="bg-[#050812] border border-slate-900 p-4 rounded-2xl flex flex-col font-mono text-xs w-full md:w-auto relative group">
            <div className="absolute inset-0 bg-white/[0.01] rounded-2xl pointer-events-none" />
            <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">PAYEE BANKING COORDINATES:</span>
            <span className="text-blue-400 font-extrabold mt-1 tracking-wide select-all text-sm">{settings.upiId}</span>
          </div>
        </div>

        {/* Content Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Column Left: QR and Scan Guide */}
          <div className="lg:col-span-5 space-y-6">
            <div className="sticky top-24 space-y-6">
              
              {/* Wrapped QRCode Generator inside TiltCard */}
              <TiltCard>
                <div className="p-1 bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-950 rounded-3xl border border-slate-800">
                  <QRCodeGenerator 
                    upiId={settings.upiId} 
                    businessName={settings.businessName}
                    amount={amount || undefined} 
                  />
                </div>
              </TiltCard>

              {/* Guide Playbook Card */}
              <div className="bg-slate-900/40 backdrop-blur-xl border border-slate-850/60 rounded-3xl p-6 shadow-xl relative">
                <div className="absolute top-4 right-4 text-indigo-500">
                  <Coins className="w-5 h-5 opacity-40" />
                </div>
                
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-450 mb-5 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-500" />
                  Security Payment Playbook
                </h3>
                
                <ol className="space-y-4 text-xs text-slate-400">
                  <li className="flex items-start gap-3">
                    <span className="w-5.5 h-5.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-center font-bold text-white text-[11px] flex-shrink-0">1</span>
                    <span className="leading-normal">Point and scan the QR using any secure UPI-enabled billing client, or enter the UPI handle manually.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-5.5 h-5.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-center font-bold text-white text-[11px] flex-shrink-0">2</span>
                    <span className="leading-normal">Complete the cash transaction of the exact amount specified within your chosen UPI client.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-5.5 h-5.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-center font-bold text-white text-[11px] flex-shrink-0">3</span>
                    <span className="leading-normal">Acquire the <strong>12-digit numeric UTR / Transaction reference code</strong> from your payment success log.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-5.5 h-5.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-center font-bold text-white text-[11px] flex-shrink-0">4</span>
                    <span className="leading-normal">Submit your details on the right form block along with the UTR code to secure instantaneous audit verification.</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>

          {/* Column Right: Submit Details Dark Glass Form */}
          <div className="lg:col-span-7 bg-slate-900/20 backdrop-blur-xl border border-slate-850/60 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute -inset-0.5 bg-gradient-to-tr from-blue-500/5 to-transparent pointer-events-none" />
            
            <div className="mb-6 pb-4 border-b border-slate-850/60 flex items-center justify-between">
              <div>
                <h2 className="text-base font-extrabold text-white font-sora tracking-tight">Audit Manifest</h2>
                <p className="text-xs text-slate-450 mt-1">Direct safe bank statement settlement voucher inputs</p>
              </div>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>

            {prefilledRemarks && (
              <div className="mb-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl flex items-start gap-3" id="prefilled-remarks-alert">
                <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-slate-300">
                  <span className="font-extrabold uppercase tracking-widest text-[9px] text-blue-400 block mb-1">Payment Reference Marks</span>
                  <div className="space-y-1">
                    <p>Dynamic amount lock enabled for <strong className="text-white font-black">₹{amount.toFixed(2)}</strong>.</p>
                    <p><strong className="text-slate-400 font-semibold">Purpose:</strong> {prefilledRemarks}</p>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Validation Alert */}
              {validationError && (
                <div className="bg-red-500/10 text-red-400 border border-red-500/30 rounded-2xl p-4 text-xs font-semibold">
                  {validationError}
                </div>
              )}

              {/* Amount form field */}
              <div className="space-y-2 text-left">
                <label className="text-xs font-extrabold text-slate-350 block uppercase tracking-wider">
                  Amount Deposited (INR) *
                </label>
                <div className="relative group">
                  <span className="absolute left-4.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold font-mono text-base group-focus-within:text-blue-400 transition-colors">₹</span>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={amount}
                    onChange={e => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value) || 0)}
                    placeholder="Enter transferred amount matching UPI receipt"
                    className="w-full bg-[#050812] border border-slate-800 focus:border-blue-500 rounded-2xl p-4 pl-9 text-white font-extrabold text-base transition-all outline-none"
                  />
                </div>
                <p className="text-[10px] text-slate-500">Provide the precise numerical credit amount matching your UPI receipt exactly.</p>
              </div>

              {/* Name form field */}
              <div className="space-y-2 text-left">
                <label className="text-xs font-extrabold text-slate-355 block uppercase tracking-wider">
                  Customer Identity Profile Name *
                </label>
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-blue-400 transition-colors" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Enter name corresponding to UPI account"
                    className="w-full bg-[#050812] border border-slate-800 focus:border-blue-500 rounded-2xl p-4 pl-11 text-xs text-white font-medium transition-all outline-none"
                  />
                </div>
              </div>

              {/* Mobile and Email row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Mobile field */}
                <div className="space-y-2 text-left">
                  <label className="text-xs font-extrabold text-[#D1D5DB] block uppercase tracking-wider">
                    Receipt Claim Phone *
                  </label>
                  <div className="relative group">
                    <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-blue-405 transition-colors" />
                    <input
                      type="tel"
                      required
                      value={mobile}
                      onChange={e => setMobile(e.target.value)}
                      placeholder="Enter 10-12 digit mobile key"
                      className="w-full bg-[#050812] border border-slate-800 focus:border-blue-500 rounded-2xl p-4 pl-11 text-xs text-white font-mono transition-all outline-none"
                    />
                  </div>
                  <p className="text-[9px] text-slate-505">Search query key for tracing your settlement live.</p>
                </div>

                {/* Email Optional field */}
                <div className="space-y-2 text-left">
                  <label className="text-xs font-extrabold text-[#D1D5DB] block uppercase tracking-wider">
                    E-Mail <span className="text-slate-500 font-normal leading-none">(Optional)</span>
                  </label>
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-blue-405 transition-colors" />
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="receipt@yourdomain.net"
                      className="w-full bg-[#050812] border border-slate-800 focus:border-blue-500 rounded-2xl p-4 pl-11 text-xs text-white font-medium transition-all outline-none"
                    />
                  </div>
                </div>

              </div>

              {/* UTR reference ID field */}
              <div className="space-y-2 text-left">
                <label className="text-xs font-extrabold text-blue-450 block uppercase tracking-wider">
                  12-Digit Numeric UTR Reference ID *
                </label>
                <div className="relative group">
                  <FileText className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-500 w-4 h-4" />
                  <input
                    type="text"
                    required
                    maxLength={12}
                    value={utr}
                    onChange={e => setUtr(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="Input exact numerical REF / UTR code (12 digits)"
                    className="w-full bg-blue-500/[0.03] border border-blue-500/40 focus:border-blue-500 rounded-2xl p-4 pl-11 text-xs sm:text-sm text-yellow-400 font-mono font-bold tracking-widest transition-all outline-none placeholder:font-sans placeholder:tracking-normal placeholder:text-slate-505"
                  />
                </div>
                <p className="text-[10px] text-slate-500 leading-normal">
                  UPI payments always output an exclusive 12-digit transaction ID (e.g., <code className="font-bold text-slate-350">324905142831</code>). Double check with your payment slip details.
                </p>
              </div>

              {/* Screenshot Image Attachment Optional */}
              <div className="space-y-2 text-left">
                <label className="text-xs font-extrabold text-[#D1D5DB] block uppercase tracking-wider">
                  Voucher Screenshot Image <span className="text-slate-550 font-normal leading-none">(Optional)</span>
                </label>
                
                {screenshot ? (
                  <div className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 rounded-2xl relative">
                    <img 
                      src={screenshot} 
                      alt="receipt-preview" 
                      className="w-12 h-12 rounded-lg object-cover border border-slate-800" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-grow min-w-0">
                      <p className="text-xs font-bold text-white truncate">{fileName || 'screenshot.png'}</p>
                      <p className="text-[10px] text-emerald-400">Photo voucher loaded</p>
                    </div>
                    <button
                      type="button"
                      onClick={clearScreenshot}
                      className="p-1.5 text-slate-500 hover:text-white rounded-lg cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-slate-800 hover:border-slate-700 cursor-pointer p-6 rounded-2xl text-center bg-[#050812] group relative transition-colors">
                    <input
                      type="file"
                      id="screenshot-input"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <label htmlFor="screenshot-input" className="cursor-pointer block">
                      <Upload className="w-8 h-8 text-slate-550 group-hover:text-blue-400 mx-auto mb-2 transition-colors" />
                      <span className="text-xs font-bold text-slate-300 block group-hover:text-white transition-colors">
                        Click / Drag receipt image
                      </span>
                      <span className="text-[10px] text-slate-500 mt-1 block">Supports JPG, PNG up to 2MB</span>
                    </label>
                  </div>
                )}
              </div>

              {/* Submit panel Button */}
              <div className="pt-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-550 hover:to-blue-650 text-white font-extrabold text-xs uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-blue-500/10 flex items-center justify-center gap-2 group disabled:opacity-50 cursor-pointer active:scale-98"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Verifying Coordinates & Securing Records...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" />
                      <span>Submit Manual Verification Ticket</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>

        </div>
      </div>
    </div>
  );
}
