/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { Payment } from '../types';
import ReceiptModal from './ReceiptModal';
import { 
  Search, 
  Smartphone, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Info, 
  MessageSquare, 
  FileText,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
  Award
} from 'lucide-react';

interface PaymentStatusProps {
  initialMobile?: string;
  initialUtr?: string;
  onBackToLanding: () => void;
  whatsappNumber: string;
}

export default function PaymentStatus({ initialMobile = '', initialUtr = '', onBackToLanding, whatsappNumber }: PaymentStatusProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<Payment[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [receiptPayment, setReceiptPayment] = useState<Payment | null>(null);

  // Handle defaults if redirecting from submission success
  useEffect(() => {
    if (initialMobile || initialUtr) {
      const q = initialUtr || initialMobile;
      setSearchQuery(q);
      const matched = db.searchCustomerPayments(q);
      setResults(matched);
      setHasSearched(true);
    }
  }, [initialMobile, initialUtr]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');
    setHasSearched(false);

    const cleanQuery = searchQuery.trim();
    if (!cleanQuery) {
      return setValidationError('Please enter your exact mobile number or 12-digit UTR ID to search.');
    }

    // Guard to ensure query has sufficient digits, shielding against brute-force guessing of other customers' accounts
    const formattedQuery = cleanQuery.replace(/[^0-9a-zA-Z]/g, '');
    if (formattedQuery.length < 10) {
      return setValidationError('Query too short. To protect buyer privacy, you must search by entering your exact 10-digit mobile number or 12-digit reference UTR.');
    }

    const matched = db.searchCustomerPayments(cleanQuery);
    setResults(matched);
    setHasSearched(true);
  };

  const getStatusStyle = (status: Payment['status']) => {
    switch (status) {
      case 'verified':
        return {
          bg: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400',
          indicator: 'bg-emerald-500',
          label: 'Verified Settle Success',
          icon: <CheckCircle className="w-4 h-4 text-emerald-400" />
        };
      case 'rejected':
        return {
          bg: 'bg-rose-500/10 border-rose-500/20 text-rose-405',
          indicator: 'bg-rose-500',
          label: 'Rejected Entry',
          icon: <XCircle className="w-4 h-4 text-rose-405" />
        };
      default:
        return {
          bg: 'bg-amber-500/10 border-amber-500/20 text-amber-400',
          indicator: 'bg-amber-500 animate-pulse',
          label: 'Pending Manual Audit',
          icon: <Clock className="w-4 h-4 text-amber-400" />
        };
    }
  };

  return (
    <div id="payment-status-wrapper" className="min-h-screen bg-[#020617] text-white selection:bg-blue-600 relative pb-16">
      
      {/* Search Header Hero Bar */}
      <div className="bg-gradient-to-tr from-[#0F172A]/80 via-[#070b19]/80 to-[#10132e]/50 border-b border-slate-900 py-16 px-4 shadow-2xl relative overflow-hidden">
        
        {/* Lights backgrounds */}
        <div className="absolute top-0 right-0 -m-16 w-80 h-80 bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none select-none"></div>
        <div className="absolute bottom-0 left-[15%] -m-16 w-80 h-80 bg-blue-500/5 rounded-full blur-[120px] pointer-events-none select-none"></div>

        <div className="max-w-xl mx-auto text-center relative z-10 space-y-4">
          <button
            onClick={onBackToLanding}
            className="inline-flex items-center gap-2 px-4.5 py-2.5 bg-slate-900 border border-slate-800 text-slate-350 hover:bg-slate-850 hover:text-white text-[10px] font-extrabold uppercase tracking-widest rounded-xl cursor-pointer transition-all active:scale-98"
          >
            ← Back to Landing Page
          </button>
          
          <h1 className="text-3xl md:text-4xl font-black font-sora tracking-tight">Manual Payment Tracking</h1>
          
          <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
            Provide the 12-digit UPI UTR transaction reference key or customer mobile handle to fetch settlement ledger entries.
          </p>

          {/* Search Inputs Group */}
          <form onSubmit={handleSearch} className="max-w-md mx-auto pt-4">
            <div className="relative group">
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Enter 12-digit UTR Code or Mobile"
                className="w-full pl-5 pr-14 py-4 bg-[#050812] border border-slate-805/80 rounded-2xl text-xs text-white font-mono font-bold tracking-widest outline-none focus:border-blue-550 transition-all placeholder:font-sans placeholder:tracking-normal placeholder:text-slate-505"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-blue-600 hover:bg-blue-550 text-white rounded-xl flex items-center justify-center transition-all shadow-md shadow-blue-500/10 cursor-pointer active:scale-95"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>
            
            {validationError && (
              <p className="text-rose-400 font-bold text-xs mt-2.5 text-left">{validationError}</p>
            )}
            
            <p className="text-[10px] text-slate-500 mt-3 text-left font-sans flex items-center gap-1.5 leading-none">
              <Smartphone className="w-4 h-4 text-slate-600" />
              <span>Query tip: Search by phone to recover history records automatically.</span>
            </p>
          </form>

        </div>
      </div>

      {/* Main Results Container */}
      <div className="max-w-3xl mx-auto px-4 py-12 relative z-10">
        
        {hasSearched ? (
          <div className="space-y-6">
            <h2 className="text-xs font-black uppercase tracking-widest text-slate-500 border-b border-slate-900 pb-2 flex items-center gap-2">
              <span>Audit Matches</span>
              <span className="bg-slate-900 px-2 py-0.5 rounded-md text-[10px] text-slate-400">{results.length} found</span>
            </h2>

            {results.length > 0 ? (
              results.map((p) => {
                const sObj = getStatusStyle(p.status);
                return (
                  <div 
                    key={p.id} 
                    className="bg-slate-900/20 backdrop-blur-xl border border-slate-850/60 rounded-3xl p-6 shadow-2xl relative overflow-hidden"
                  >
                    {/* Status side indicator border line */}
                    <div className={`absolute top-0 bottom-0 left-0 w-1.5 ${sObj.indicator}`}></div>

                    {/* Header Line */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-850/60 pb-5 mb-5">
                      <div>
                        <div className="text-[9px] text-slate-500 font-extrabold uppercase tracking-wider">UTR Transaction Identifier</div>
                        <div className="font-mono text-base font-extrabold text-[#ffffff] flex items-center gap-2 mt-0.5 tracking-wide">
                          {p.utrNumber}
                        </div>
                      </div>

                      <div className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full border text-[10px] font-extrabold uppercase tracking-wider ${sObj.bg}`}>
                        {sObj.icon}
                        <span>{sObj.label}</span>
                      </div>
                    </div>

                    {/* Core details grid */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-5 text-xs">
                      <div>
                        <span className="text-slate-500 font-bold block uppercase tracking-wider text-[8.5px]">Payer Identity</span>
                        <span className="text-white font-extrabold mt-1.5 block">{p.customerName}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 font-bold block uppercase tracking-wider text-[8.5px]">Amount Claimed</span>
                        <span className="text-emerald-400 font-extrabold text-sm mt-1 block">₹{p.amount.toFixed(2)}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 font-bold block uppercase tracking-wider text-[8.5px]">Voucher Date</span>
                        <span className="text-slate-350 font-mono mt-1 block">{new Date(p.date).toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 font-bold block uppercase tracking-wider text-[8.5px]">Contact Key</span>
                        <span className="text-slate-350 font-mono mt-1 block">{p.mobile}</span>
                      </div>
                    </div>

                    {/* Progress step visual timeline */}
                    <div className="my-6 p-4 bg-slate-950/60 border border-slate-850/40 rounded-2xl">
                      <div className="text-[9px] font-black text-slate-550 uppercase tracking-widest mb-4">Reconciliation Timeline</div>
                      
                      <div className="relative flex flex-col sm:flex-row justify-between gap-6 sm:gap-2">
                        {/* Horizontal path line */}
                        <div className="hidden sm:block absolute top-[9px] left-[5%] right-[5%] h-[1px] bg-slate-800"></div>

                        {/* Step 1 */}
                        <div className="flex sm:flex-col items-center sm:items-start gap-4 sm:gap-2 flex-1 relative text-left">
                          <div className="w-5.5 h-5.5 bg-emerald-500 rounded-xl flex items-center justify-center text-white text-[10px] font-bold shadow-md z-15">✓</div>
                          <div>
                            <span className="text-[11px] font-semibold text-white block">Checkout Submission</span>
                            <span className="text-[9px] text-slate-500 block mt-0.5">{new Date(p.date).toLocaleDateString()}</span>
                          </div>
                        </div>

                        {/* Step 2 */}
                        <div className="flex sm:flex-col items-center sm:items-start gap-4 sm:gap-2 flex-1 relative text-left">
                          <div className={`w-5.5 h-5.5 rounded-xl flex items-center justify-center text-white text-[10px] font-bold shadow-md z-15 ${
                            p.status !== 'pending' ? 'bg-emerald-500' : 'bg-amber-400 animate-pulse'
                          }`}>
                            {p.status !== 'pending' ? '✓' : '●'}
                          </div>
                          <div>
                            <span className="text-[11px] font-semibold text-white block">Raw Statement Verifying</span>
                            <span className="text-[9px] text-slate-500 block mt-0.5">
                              {p.status !== 'pending' ? 'Bank ledger confirmed' : 'Awaiting manual entry reconcile'}
                            </span>
                          </div>
                        </div>

                        {/* Step 3 */}
                        <div className="flex sm:flex-col items-center sm:items-start gap-4 sm:gap-2 flex-1 relative text-left">
                          <div className={`w-5.5 h-5.5 rounded-xl flex items-center justify-center text-white text-[10px] font-bold shadow-md z-15 ${
                            p.status === 'verified' ? 'bg-emerald-500' : 
                            p.status === 'rejected' ? 'bg-rose-500' : 'bg-slate-800 text-slate-500'
                          }`}>
                            {p.status === 'verified' ? '✓' : p.status === 'rejected' ? '✕' : '●'}
                          </div>
                          <div>
                            <span className="text-[11px] font-semibold text-white block">Settle Destination Succeeded</span>
                            <span className="text-[9px] text-slate-500 block mt-0.5">
                              {p.status === 'verified' ? 'Balance credited to bank' : 
                               p.status === 'rejected' ? 'Reconciliation Failed' : 'Final routing ledger hold'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Auditor remarks section */}
                    {p.adminNote && (
                      <div className="mt-4 p-4 bg-slate-950/40 border border-slate-850/60 rounded-2xl flex items-start gap-3">
                        <Info className="w-4.5 h-4.5 text-blue-450 flex-shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[8.5px] font-bold text-slate-500 uppercase tracking-widest block mb-0.5">Checkout Auditor Note</span>
                          <p className="text-xs text-slate-300 leading-relaxed font-semibold">{p.adminNote}</p>
                        </div>
                      </div>
                    )}

                    {/* WhatsApp check-in callback directly for specific payment UTR */}
                    {p.status === 'pending' && whatsappNumber && (
                      <div className="mt-4 flex justify-end">
                        <a 
                          href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                            `Hello, I filed manual payment ticket under UTR: ${p.utrNumber} for Amount ₹${p.amount.toFixed(2)}. Could you please verify this? Thanks.`
                          )}`}
                          target="_blank" 
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 px-4.5 py-2.5 bg-emerald-500 hover:bg-emerald-555 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-emerald-500/10 cursor-pointer active:scale-98"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Escalate on WhatsApp</span>
                        </a>
                      </div>
                    )}

                    {p.status === 'verified' && (
                      <div className="mt-4 flex justify-end">
                        <button
                          type="button"
                          onClick={() => setReceiptPayment(p)}
                          className="inline-flex items-center gap-2 px-4.5 py-2.5 bg-slate-850 hover:bg-slate-750 text-white text-xs font-bold rounded-xl transition-all border border-slate-800 cursor-pointer active:scale-98 hover:scale-101"
                        >
                          <svg className="w-4 h-4 text-emerald-450" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          <span>Print Verified Settle Receipt</span>
                        </button>
                      </div>
                    )}

                  </div>
                );
              })
            ) : (
              <div className="bg-slate-900/35 border border-slate-850/60 rounded-3xl p-12 text-center shadow-xl space-y-4">
                <div className="w-12 h-12 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-full flex items-center justify-center mx-auto mb-2">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <p className="text-sm font-extrabold text-slate-300">No matching ledger entries discovered.</p>
                <div className="max-w-md mx-auto bg-slate-950/45 p-4 border border-slate-850/40 rounded-2xl">
                  <p className="text-[11px] text-slate-400 font-semibold leading-relaxed">
                    <strong className="text-indigo-400 block mb-1">🔐 Privacy Shield Active</strong>
                    To protect customer accounts from unauthorized queries, partial searching is strictly forbidden. Your payment records can only be retrieved by entering either your exact, full 10-digit phone number or the complete 12-digit UTR bank reference code.
                  </p>
                </div>
                
                {whatsappNumber && (
                  <div className="pt-2">
                    <a 
                      href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}`} 
                      target="_blank" 
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 hover:text-emerald-300 uppercase tracking-widest"
                    >
                      <span>Need Help? Contact support</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </a>
                  </div>
                )}
              </div>
            )}

            <button
              onClick={onBackToLanding}
              className="w-full py-4 text-xs font-bold uppercase tracking-widest text-slate-400 hover:text-white bg-[#050812] hover:bg-slate-900 border border-slate-805/80 rounded-2xl transition-all cursor-pointer"
            >
              Clear Search queries & Return
            </button>
          </div>
        ) : (
          /* Static help cards on fresh entrance */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
            <div className="p-6 bg-slate-900/20 backdrop-blur-xl border border-slate-850/60 rounded-3xl relative">
              <div className="absolute top-4 right-4 text-slate-700">
                <FileText className="w-5 h-5 opacity-30" />
              </div>
              <h3 className="text-xs font-black uppercase tracking-widest text-[#ffffff] flex items-center gap-2 mb-3">
                <Award className="w-4 h-4 text-blue-500" />
                Where is my 12 digit UTR code?
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-medium">
                The Unique Transaction Reference (UTR) is a 12-digit numeric code generated by your bank immediately on completion of payment. You will find it labeled as "UTR", "UPI Ref No", "Bank Ref ID", or "Transaction Reference Index" in your standard bank app or UPI client wallet history slip.
              </p>
            </div>

            <div className="p-6 bg-slate-900/20 backdrop-blur-xl border border-slate-850/60 rounded-3xl relative">
              <div className="absolute top-4 right-4 text-slate-700">
                <HelpCircle className="w-5 h-5 opacity-30" />
              </div>
              <h3 className="text-xs font-black uppercase tracking-widest text-[#ffffff] flex items-center gap-2 mb-3">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                Reconciliation Speeds
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-semibold">
                Direct bank confirmation is 100% immune from payment gateway failures, intermediate commission leakage, and automated API downtime. Verification typically settles within 10-25 minutes.
              </p>
            </div>
          </div>
        )}

      </div>

      {receiptPayment && (
        <ReceiptModal 
          payment={receiptPayment} 
          onClose={() => setReceiptPayment(null)}
        />
      )}

    </div>
  );
}
