/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { db } from '../services/db';
import { Payment, PaymentStatus } from '../types';
import { Filter, Download, FileText, RefreshCw, Calendar, IndianRupee } from 'lucide-react';

export default function ReportDownloader() {
  const [payments, setPayments] = useState<Payment[]>(() => db.getPayments());
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [status, setStatus] = useState<PaymentStatus | 'all'>('all');
  const [minAmount, setMinAmount] = useState('');
  const [maxAmount, setMaxAmount] = useState('');
  const [printError, setPrintError] = useState('');

  const handleRefresh = () => {
    setPayments(db.getPayments());
  };

  // Filter payments dynamically
  const filteredPayments = payments.filter(p => {
    const paymentDate = new Date(p.date);
    
    // Filter by start date
    if (startDate) {
      const start = new Date(startDate);
      start.setHours(0, 0, 0, 0);
      if (paymentDate < start) return false;
    }

    // Filter by end date
    if (endDate) {
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      if (paymentDate > end) return false;
    }

    // Filter by status
    if (status !== 'all' && p.status !== status) return false;

    // Filter by min amount
    if (minAmount && p.amount < parseFloat(minAmount)) return false;

    // Filter by max amount
    if (maxAmount && p.amount > parseFloat(maxAmount)) return false;

    return true;
  });

  const exportCSV = () => {
    const headers = ['ID', 'Date', 'Customer Name', 'Mobile', 'Email', 'Amount (INR)', 'UTR Number', 'Status', 'Admin Note', 'Status Changed At'];
    const rows = filteredPayments.map(p => [
      p.id,
      new Date(p.date).toLocaleString(),
      p.customerName,
      p.mobile,
      p.email || '',
      p.amount.toString(),
      p.utrNumber,
      p.status.toUpperCase(),
      p.adminNote || '',
      p.statusChangedAt ? new Date(p.statusChangedAt).toLocaleString() : ''
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `ZuelPay_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPDF = () => {
    // We can open a beautiful print window representing a clean PDF ledger
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      setPrintError('Please allow popups to download/print PDF reports.');
      return;
    }
    setPrintError('');

    const rowsHTML = filteredPayments.map((p, idx) => `
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="padding: 10px; font-size: 11px;">${idx + 1}</td>
        <td style="padding: 10px; font-size: 11px;">${new Date(p.date).toLocaleString()}</td>
        <td style="padding: 10px; font-size: 11px; font-weight: 550;">${p.customerName}</td>
        <td style="padding: 10px; font-size: 11px; font-family: monospace;">${p.mobile}</td>
        <td style="padding: 10px; font-size: 11px; font-weight: 600;">₹${p.amount.toFixed(2)}</td>
        <td style="padding: 10px; font-size: 11px; font-family: monospace; letter-spacing: 0.5px;">${p.utrNumber}</td>
        <td style="padding: 10px; font-size: 11px; text-transform: uppercase;">
          <span style="padding: 2px 6px; border-radius: 4px; font-weight: bold; font-size: 9px; 
            ${p.status === 'verified' ? 'background: #d1fae5; color: #065f46;' : ''}
            ${p.status === 'pending' ? 'background: #fef3c7; color: #92400e;' : ''}
            ${p.status === 'rejected' ? 'background: #fee2e2; color: #991b1b;' : ''}
          ">
            ${p.status}
          </span>
        </td>
      </tr>
    `).join('');

    const totalStats = filteredPayments.reduce((acc, current) => {
      acc.total += current.amount;
      if (current.status === 'verified') acc.verified += current.amount;
      return acc;
    }, { total: 0, verified: 0 });

    printWindow.document.write(`
      <html>
        <head>
          <title>ZuelPay Transaction Report - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #1e293b; padding: 40px; margin: 0; }
            .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0f172a; padding-bottom: 20px; }
            .title { font-size: 24px; font-weight: 800; color: #0f172a; margin: 0; letter-spacing: -0.5px; }
            .subtitle { font-size: 12px; color: #64748b; margin-top: 5px; }
            .meta-info { font-size: 11px; text-align: right; color: #64748b; }
            .summary-cards { display: flex; gap: 20px; margin: 30px 0; }
            .card { flex: 1; border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px; background: #f8fafc; }
            .card-title { font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: bold; letter-spacing: 0.5px; }
            .card-value { font-size: 20px; font-weight: 800; color: #0f172a; margin-top: 5px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; text-align: left; }
            th { background: #0f172a; color: white; padding: 12px 10px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
            .footer { margin-top: 50px; text-align: center; font-size: 10px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="title">ZuelPay Verification Statement</div>
              <div class="subtitle">Manual UPI Payment Records Report Log</div>
            </div>
            <div class="meta-info">
              <div>Export date: ${new Date().toLocaleString()}</div>
              <div>Report Filter: ${status.toUpperCase()} Status</div>
              <div>Matching Records Count: ${filteredPayments.length} Items</div>
            </div>
          </div>

          <div class="summary-cards">
            <div class="card">
              <div class="card-title">Aggregated Filtered Volume</div>
              <div class="card-value">₹${totalStats.total.toFixed(2)}</div>
            </div>
            <div class="card">
              <div class="card-title">Verified Filtered Volume</div>
              <div class="card-value" style="color: #059669;">₹${totalStats.verified.toFixed(2)}</div>
            </div>
            <div class="card">
              <div class="card-title">Report Scope Status</div>
              <div class="card-value" style="color: #2563eb; text-transform: uppercase; font-size: 16px;">${status === 'all' ? 'All Transactions' : status}</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="border-top-left-radius: 6px;">#</th>
                <th>Date</th>
                <th>Customer Name</th>
                <th>Mobile</th>
                <th>Amount</th>
                <th>UTR Verification ID</th>
                <th style="border-top-right-radius: 6px;">Status</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHTML || '<tr><td colspan="7" style="padding: 20px; text-align: center; color: #94a3b8; font-size: 12px;">No matching records found.</td></tr>'}
            </tbody>
          </table>

          <div class="footer">
            Generated securely by ZuelPay Audit Engine. This is an authentic manual ledger report sync.
          </div>
          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div id="report-downloader" className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Filter className="w-5 h-5 text-blue-600" />
            Audit Report Engine
          </h2>
          <p className="text-xs text-slate-500">Filter, query, and instant export transaction ledgers for accounting verification</p>
        </div>
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Synchronize Local DB
        </button>
      </div>

      {printError && (
        <div className="mb-4 p-3.5 bg-amber-500/10 border border-amber-500/20 text-amber-500 text-xs font-semibold rounded-xl flex items-center justify-between gap-2" id="print-error-toast">
          <span>{printError}</span>
          <button onClick={() => setPrintError('')} className="text-[10px] hover:text-amber-700 font-bold uppercase">Dismiss</button>
        </div>
      )}

      {/* Filter Matrix Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
        
        {/* Date Filters */}
        <div className="space-y-1.5 col-span-1 sm:col-span-2 md:col-span-1">
          <label className="text-xs font-semibold text-slate-500 flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            Date Scope
          </label>
          <div className="flex gap-2">
            <input
              type="date"
              value={startDate}
              onChange={e => setStartDate(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl p-2.5 text-slate-700 font-mono transition-all outline-none"
              placeholder="From"
            />
            <input
              type="date"
              value={endDate}
              onChange={e => setEndDate(e.target.value)}
              className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl p-2.5 text-slate-700 font-mono transition-all outline-none"
              placeholder="To"
            />
          </div>
        </div>

        {/* Status Filter */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-500">Payment Status</label>
          <select
            value={status}
            onChange={e => setStatus(e.target.value as PaymentStatus | 'all')}
            className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl p-2.5 text-slate-700 font-medium transition-all outline-none"
          >
            <option value="all">All Statuses (Pending &amp; Settled)</option>
            <option value="pending">Pending Verification</option>
            <option value="verified">Verified Payments Only</option>
            <option value="rejected">Rejected Entries Only</option>
          </select>
        </div>

        {/* Amount filter */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-500 flex items-center gap-1">
            <IndianRupee className="w-3.5 h-3.5 text-slate-400" />
            Amount Range (INR)
          </label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              value={minAmount}
              onChange={e => setMinAmount(e.target.value)}
              placeholder="Min"
              className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl p-2.5 text-slate-700 font-mono transition-all outline-none"
            />
            <span className="text-slate-400 text-xs font-mono">-</span>
            <input
              type="number"
              value={maxAmount}
              onChange={e => setMaxAmount(e.target.value)}
              placeholder="Max"
              className="w-full text-xs bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl p-2.5 text-slate-700 font-mono transition-all outline-none"
            />
          </div>
        </div>
      </div>

      {/* Stats and Action Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 bg-slate-50 border border-slate-200/60 rounded-xl">
        <div className="text-xs text-slate-600">
          Filtered Results: <span className="font-bold text-slate-950 font-mono text-sm bg-white border border-slate-200 px-2 py-0.5 rounded-md shadow-inner">{filteredPayments.length}</span> matching payments
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          {/* Export CSV button */}
          <button
            onClick={exportCSV}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-100 font-semibold text-xs transition-colors shadow-sm"
          >
            <Download className="w-4 h-4 text-emerald-500" />
            Export CSV
          </button>

          {/* Export PDF style print ledger button */}
          <button
            onClick={handlePrintPDF}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-900 text-white rounded-xl hover:bg-slate-800 font-semibold text-xs transition-colors shadow-sm"
          >
            <FileText className="w-4 h-4 text-blue-400" />
            Print PDF Ledger
          </button>
        </div>
      </div>
    </div>
  );
}
