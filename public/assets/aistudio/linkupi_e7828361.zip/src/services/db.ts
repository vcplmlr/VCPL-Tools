/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BusinessSettings, Payment, Customer, AuditLog, PaymentStatus, AdminUser, ShortUrl } from '../types';

export interface RegisteredAccount {
  username: string;
  passwordHash: string;
  role: 'admin' | 'merchant';
  securityQuestion: string;
  securityAnswer: string;
}

const STORAGE_KEYS = {
  SETTINGS: 'zuelpay_business_settings',
  PAYMENTS: 'zuelpay_payments',
  AUDIT_LOGS: 'zuelpay_audit_logs',
  AUTH: 'zuelpay_auth_user',
  ACCOUNTS: 'zuelpay_accounts_db',
  SHORT_URLS: 'zuelpay_short_urls',
  CUSTOM_CUSTOMERS: 'zuelpay_custom_customers',
};

const DEFAULT_ACCOUNTS: RegisteredAccount[] = [
  {
    username: 'admin',
    passwordHash: 'admin123',
    role: 'admin',
    securityQuestion: 'What is your security gateway key name?',
    securityAnswer: 'zuelpay',
  }
];

// Default setup values
const DEFAULT_SETTINGS: BusinessSettings = {
  accountType: 'business',
  businessName: '',
  address: '',
  upiId: '',
  upiQrImage: '', // Will fall back to a dynamic elegant vector SVG QR
  whatsappNumber: '',
  supportEmail: '',
};

const DEFAULT_PAYMENTS: Payment[] = [];

const DEFAULT_AUDIT_LOGS: AuditLog[] = [];

// Helper to check and load from storage or save default
const getFromStorage = <T>(key: string, defaultValue: T): T => {
  try {
    let item = localStorage.getItem(key);
    if (!item) {
      // Backward-compatibility fallback for existing linkupi keys
      const legacyKey = key.replace('zuelpay_', 'linkupi_');
      const legacyItem = localStorage.getItem(legacyKey);
      if (legacyItem) {
        item = legacyItem;
        localStorage.setItem(key, legacyItem);
      }
    }
    if (!item) {
      localStorage.setItem(key, JSON.stringify(defaultValue));
      return defaultValue;
    }
    return JSON.parse(item);
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return defaultValue;
  }
};

const saveToStorage = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error writing ${key} to storage:`, e);
  }
};

// Database engine simulating Supabase API
export const db = {
  // Business Settings Table Operations
  getSettings(): BusinessSettings {
    return getFromStorage<BusinessSettings>(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  },

  updateSettings(settings: Partial<BusinessSettings>): BusinessSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    saveToStorage(STORAGE_KEYS.SETTINGS, updated);
    this.addAuditLog('update_settings', `Updated payee profile settings: ${settings.businessName || ''}`);
    return updated;
  },

  // Payments Table Operations
  getPayments(): Payment[] {
    return getFromStorage<Payment[]>(STORAGE_KEYS.PAYMENTS, DEFAULT_PAYMENTS);
  },

  getPayment(id: string): Payment | undefined {
    return this.getPayments().find(p => p.id === id);
  },

  submitPayment(paymentData: Omit<Payment, 'id' | 'date' | 'status'>): Payment {
    const payments = this.getPayments();
    const newPayment: Payment = {
      ...paymentData,
      id: `pay_${Date.now()}`,
      date: new Date().toISOString(),
      status: 'pending'
    };
    payments.unshift(newPayment); // Add to the top
    saveToStorage(STORAGE_KEYS.PAYMENTS, payments);
    return newPayment;
  },

  updatePaymentStatus(id: string, status: PaymentStatus, note?: string, adminUser = 'Admin'): Payment | null {
    const payments = this.getPayments();
    const index = payments.findIndex(p => p.id === id);
    if (index === -1) return null;

    const oldStatus = payments[index].status;
    payments[index].status = status;
    payments[index].statusChangedAt = new Date().toISOString();
    if (note !== undefined) {
      payments[index].adminNote = note;
    }

    saveToStorage(STORAGE_KEYS.PAYMENTS, payments);

    // Add Audit Log
    this.addAuditLog(
      'status_change',
      `Payment ${id} changed from '${oldStatus}' to '${status}'. Note: ${note || 'None'}`,
      adminUser
    );

    return payments[index];
  },

  addAdminNote(id: string, note: string): Payment | null {
    const payments = this.getPayments();
    const index = payments.findIndex(p => p.id === id);
    if (index === -1) return null;

    payments[index].adminNote = note;
    saveToStorage(STORAGE_KEYS.PAYMENTS, payments);
    return payments[index];
  },

  searchCustomerPayments(query: string): Payment[] {
    const payments = this.getPayments();
    const cleanQuery = query.trim().replace(/[^0-9a-zA-Z]/g, '').toLowerCase();
    if (!cleanQuery) return [];

    return payments.filter(p => {
      const cleanMobile = p.mobile.replace(/[^0-9a-zA-Z]/g, '').toLowerCase();
      const cleanUtr = p.utrNumber.replace(/[^0-9a-zA-Z]/g, '').toLowerCase();
      const cleanReceipt = p.receiptNo ? p.receiptNo.replace(/[^0-9a-zA-Z]/g, '').toLowerCase() : '';
      // Enforce exact matching for privacy: must equal full mobile number, full UTR address, or exact Receipt ID Code
      return cleanMobile === cleanQuery || cleanUtr === cleanQuery || (cleanReceipt && cleanReceipt === cleanQuery);
    });
  },

  getCustomCustomers(): Customer[] {
    return getFromStorage<Customer[]>(STORAGE_KEYS.CUSTOM_CUSTOMERS, []);
  },

  addCustomCustomer(customerData: Omit<Customer, 'id' | 'totalPaid' | 'lastPaymentDate' | 'status'>): Customer {
    const custom = this.getCustomCustomers();
    const newCust: Customer = {
      ...customerData,
      id: `cust_reg_${Date.now()}`,
      totalPaid: 0,
      lastPaymentDate: 'No payments logged yet',
      status: 'pending',
    };
    custom.unshift(newCust);
    saveToStorage(STORAGE_KEYS.CUSTOM_CUSTOMERS, custom);
    this.addAuditLog('add_customer', `Added customer profile '${newCust.name}' with mobile: ${newCust.mobile}`);
    return newCust;
  },

  updateCustomCustomer(id: string, updates: Partial<Customer>): Customer | null {
    const custom = this.getCustomCustomers();
    const index = custom.findIndex(c => c.id === id);
    if (index === -1) return null;
    
    custom[index] = { ...custom[index], ...updates };
    saveToStorage(STORAGE_KEYS.CUSTOM_CUSTOMERS, custom);
    this.addAuditLog('update_customer', `Updated customer profile '${custom[index].name}' (${id})`);
    return custom[index];
  },

  deleteCustomCustomer(id: string): boolean {
    const custom = this.getCustomCustomers();
    const filtered = custom.filter(c => c.id !== id);
    if (filtered.length === custom.length) return false;
    saveToStorage(STORAGE_KEYS.CUSTOM_CUSTOMERS, filtered);
    this.addAuditLog('delete_customer', `Deleted custom customer profile ID: ${id}`);
    return true;
  },

  // Derived Customers Table (as requested: Store Name, Mobile, Email, Total Paid, Last Payment Date, Payment Status)
  getCustomers(): Customer[] {
    const payments = this.getPayments();
    const customReg = this.getCustomCustomers();
    const customerMap = new Map<string, Customer>();

    // Seed map with manually managed custom customer entries first
    for (const cust of customReg) {
      const key = cust.mobile.trim();
      customerMap.set(key, {
        ...cust,
        totalPaid: 0,
        lastPaymentDate: 'No payments logged yet',
        status: 'pending'
      });
    }

    // Process all payments chronologically (oldest to newest) to aggregate correctly
    const sortedPayments = [...payments].reverse();

    for (const pay of sortedPayments) {
      const key = pay.mobile.trim();
      const existing = customerMap.get(key);

      const paymentAmount = pay.status === 'verified' ? pay.amount : 0;

      if (existing) {
        existing.totalPaid += paymentAmount;
        existing.lastPaymentDate = pay.date;
        existing.status = pay.status; // Interim latest status
        if (pay.email) existing.email = pay.email;
        if (pay.customerName) existing.name = pay.customerName;
      } else {
        customerMap.set(key, {
          id: `cust_${key}`,
          name: pay.customerName,
          mobile: pay.mobile,
          email: pay.email,
          totalPaid: paymentAmount,
          lastPaymentDate: pay.date,
          status: pay.status
        });
      }
    }

    // Calculate dynamic billing-cycle statuses
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    for (const [key, c] of customerMap.entries()) {
      const customerPayments = payments.filter(p => p.mobile.trim() === key);
      
      const isRegisteredSubscriber = customReg.some(cr => cr.mobile.trim() === key);
      const subType = c.subscriptionType || (isRegisteredSubscriber ? 'monthly' : 'none');

      if (subType === 'monthly') {
        const hasCurrentMonthVerified = customerPayments.some(p => {
          const pDate = new Date(p.date);
          return p.status === 'verified' && pDate.getFullYear() === currentYear && pDate.getMonth() === currentMonth;
        });

        if (hasCurrentMonthVerified) {
          c.status = 'verified';
        } else {
          c.status = 'pending';
        }
      } else if (subType === 'yearly') {
        const hasCurrentYearVerified = customerPayments.some(p => {
          const pDate = new Date(p.date);
          return p.status === 'verified' && pDate.getFullYear() === currentYear;
        });

        if (hasCurrentYearVerified) {
          c.status = 'verified';
        } else {
          c.status = 'pending';
        }
      } else {
        // One-time or other: use latest payment status
        if (customerPayments.length > 0) {
          c.status = customerPayments[0].status;
        } else {
          c.status = 'pending';
        }
      }
    }

    // Convert back to Array
    return Array.from(customerMap.values()).reverse();
  },

  // Audit Logs Table Operations
  getAuditLogs(): AuditLog[] {
    return getFromStorage<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, DEFAULT_AUDIT_LOGS);
  },

  addAuditLog(action: string, details: string, adminUser = 'Admin'): AuditLog {
    const logs = this.getAuditLogs();
    const newLog: AuditLog = {
      id: `log_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      action,
      details,
      adminUser
    };
    logs.unshift(newLog);
    saveToStorage(STORAGE_KEYS.AUDIT_LOGS, logs);
    return newLog;
  },

  // Admin Auth Operations
  getAccounts(): RegisteredAccount[] {
    return getFromStorage<RegisteredAccount[]>(STORAGE_KEYS.ACCOUNTS, DEFAULT_ACCOUNTS);
  },

  registerAccount(username: string, passwordHash: string, securityQuestion: string, securityAnswer: string, role: 'admin' | 'merchant' = 'merchant'): { success: boolean; message: string } {
    const cleanUser = username.trim().toLowerCase();
    if (!cleanUser) {
      return { success: false, message: 'Username cannot be blank.' };
    }
    const accounts = this.getAccounts();
    const exists = accounts.some(acc => acc.username.toLowerCase() === cleanUser);
    if (exists || cleanUser === 'admin' || cleanUser === 'merchant') {
      return { success: false, message: 'Username already registered to another panelist.' };
    }

    const newAccount: RegisteredAccount = {
      username: username.trim(),
      passwordHash,
      role,
      securityQuestion,
      securityAnswer: securityAnswer.trim(),
    };

    accounts.push(newAccount);
    saveToStorage(STORAGE_KEYS.ACCOUNTS, accounts);
    this.addAuditLog('account_registered', `New secure user account registered: '${username.trim()}' (${role})`, username.trim());
    return { success: true, message: 'User authorized and registered successfully.' };
  },

  getSecurityQuestion(username: string): string | null {
    const cleanUser = username.trim().toLowerCase();
    // Default fallback admin account security question
    if (cleanUser === 'admin') {
      return 'What is your security gateway key name?';
    }
    const accounts = this.getAccounts();
    const found = accounts.find(acc => acc.username.toLowerCase() === cleanUser);
    return found ? found.securityQuestion : null;
  },

  resetAccountPassword(username: string, securityAnswer: string, passwordNew: string): { success: boolean; message: string } {
    const cleanUser = username.trim().toLowerCase();
    const cleanAns = securityAnswer.trim().toLowerCase();

    // Default admin account handcheck
    if (cleanUser === 'admin') {
      if (cleanAns === 'zuelpay' || cleanAns === 'linkupi' || cleanAns === 'admin123') {
        this.updateAdminPassword(passwordNew);
        this.addAuditLog('password_reset', `Administrator 'admin' updated password successfully via security check`, 'admin');
        return { success: true, message: 'Administrator security password updated successfully.' };
      } else {
        return { success: false, message: 'Incorrect Answer to the dynamic security checkpoint.' };
      }
    }

    const accounts = this.getAccounts();
    const index = accounts.findIndex(acc => acc.username.toLowerCase() === cleanUser);
    if (index === -1) {
      return { success: false, message: 'Account handle not found in databases.' };
    }

    const account = accounts[index];
    if (account.securityAnswer.trim().toLowerCase() !== cleanAns) {
      return { success: false, message: 'Incorrect Answer to the security verification challenge.' };
    }

    accounts[index].passwordHash = passwordNew;
    saveToStorage(STORAGE_KEYS.ACCOUNTS, accounts);
    this.addAuditLog('password_reset', `User '${account.username}' reset their access keys`, account.username);
    return { success: true, message: 'Password updated successfully. Go back to login.' };
  },

  getAdminPassword(): string {
    return localStorage.getItem('zuelpay_admin_password') || localStorage.getItem('linkupi_admin_password') || 'admin123';
  },

  updateAdminPassword(password: string): void {
    localStorage.setItem('zuelpay_admin_password', password);
    localStorage.setItem('linkupi_admin_password', password);
    const accounts = this.getAccounts();
    const adminIdx = accounts.findIndex(acc => acc.username.toLowerCase() === 'admin');
    if (adminIdx !== -1) {
      accounts[adminIdx].passwordHash = password;
      saveToStorage(STORAGE_KEYS.ACCOUNTS, accounts);
    }
    this.addAuditLog('password_reset', 'Admin security login credential key modified');
  },

  getCurrentUser(): AdminUser {
    return getFromStorage<AdminUser>(STORAGE_KEYS.AUTH, {
      username: '',
      role: 'admin',
      isLoggedIn: false,
    });
  },

  login(username: string, passwordHash: string): boolean {
    const cleanUser = username.trim().toLowerCase();
    const localAdminPass = this.getAdminPassword();
    
    // Check override default keys
    if (cleanUser === 'admin' && passwordHash === localAdminPass) {
      const authUser: AdminUser = {
        username: 'admin',
        role: 'admin',
        isLoggedIn: true
      };
      saveToStorage(STORAGE_KEYS.AUTH, authUser);
      this.addAuditLog('admin_login', `Administrator 'admin' logged in successfully`, 'admin');
      return true;
    }

    // Check custom registered users list
    const accounts = this.getAccounts();
    const found = accounts.find(acc => acc.username.toLowerCase() === cleanUser && acc.passwordHash === passwordHash);
    if (found) {
      const authUser: AdminUser = {
        username: found.username,
        role: found.role,
        isLoggedIn: true
      };
      saveToStorage(STORAGE_KEYS.AUTH, authUser);
      this.addAuditLog('admin_login', `User '${found.username}' logged in successfully`, found.username);
      return true;
    }

    // Default hardcoded fallback for merchant
    if (cleanUser === 'merchant' && passwordHash === 'merchant123') {
      const authUser: AdminUser = {
        username: 'merchant',
        role: 'merchant',
        isLoggedIn: true
      };
      saveToStorage(STORAGE_KEYS.AUTH, authUser);
      this.addAuditLog('admin_login', `User 'merchant' logged in successfully`, 'merchant');
      return true;
    }

    return false;
  },

  logout(): void {
    const user = this.getCurrentUser();
    this.addAuditLog('admin_logout', `User '${user.username}' logged out`, user.username || 'System');
    saveToStorage(STORAGE_KEYS.AUTH, {
      username: '',
      role: 'admin',
      isLoggedIn: false
    });
  },

  // Link Shortener Table Operations
  getShortUrls(): ShortUrl[] {
    return getFromStorage<ShortUrl[]>(STORAGE_KEYS.SHORT_URLS, []);
  },

  createShortUrl(amount: string, remarks: string, upi: string, name: string, phone: string, token: string): ShortUrl {
    const urls = this.getShortUrls();
    // Generate a unique 6 letter alphanumeric code
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let id = '';
    let isUnique = false;
    let attempts = 0;
    while (!isUnique && attempts < 100) {
      id = '';
      for (let i = 0; i < 6; i++) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      isUnique = !urls.some(u => u.id === id);
      attempts++;
    }

    const shortUrl: ShortUrl = {
      id,
      originalUrl: `${window.location.origin}/?d=${token}`,
      token,
      created: new Date().toISOString(),
      amount: amount || '0',
      remarks: remarks || 'Direct Settle',
      clicks: 0
    };

    urls.unshift(shortUrl);
    saveToStorage(STORAGE_KEYS.SHORT_URLS, urls);
    this.addAuditLog('link_shortened', `Shortened ID '${id}' generated for ₹${amount || '0'}`);
    return shortUrl;
  },

  incrementShortUrlClicks(id: string): void {
    const urls = this.getShortUrls();
    const index = urls.findIndex(u => u.id === id);
    if (index !== -1) {
      urls[index].clicks++;
      saveToStorage(STORAGE_KEYS.SHORT_URLS, urls);
    }
  },

  findShortUrlByToken(token: string): ShortUrl | undefined {
    return this.getShortUrls().find(u => u.token === token);
  },

  getOrCreateShortUrl(amount: string, remarks: string, upi: string, name: string, phone: string, token: string): ShortUrl {
    const urls = this.getShortUrls();
    const existing = urls.find(u => u.token === token);
    if (existing) return existing;

    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let id = '';
    let isUnique = false;
    let attempts = 0;
    while (!isUnique && attempts < 100) {
      id = '';
      for (let i = 0; i < 6; i++) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      isUnique = !urls.some(u => u.id === id);
      attempts++;
    }

    const shortUrl: ShortUrl = {
      id,
      originalUrl: `${window.location.origin}/?d=${token}`,
      token,
      created: new Date().toISOString(),
      amount: amount || '0',
      remarks: remarks || 'Direct Settle',
      clicks: 0
    };

    urls.unshift(shortUrl);
    saveToStorage(STORAGE_KEYS.SHORT_URLS, urls);
    return shortUrl;
  },

  findShortUrlById(id: string): ShortUrl | undefined {
    return this.getShortUrls().find(u => u.id === id);
  },

  // Dashboard Stats calculation
  getStats() {
    const payments = this.getPayments();
    
    let totalPayments = payments.length;
    let pendingPayments = 0;
    let verifiedPayments = 0;
    let rejectedPayments = 0;
    let todayCollection = 0;
    let thisMonthCollection = 0;

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    for (const p of payments) {
      if (p.status === 'pending') pendingPayments++;
      else if (p.status === 'verified') {
        verifiedPayments++;
        const pDate = new Date(p.date);
        
        // Count verified amount
        if (pDate >= todayStart) {
          todayCollection += p.amount;
        }
        if (pDate >= monthStart) {
          thisMonthCollection += p.amount;
        }
      } else if (p.status === 'rejected') {
        rejectedPayments++;
      }
    }

    return {
      totalPayments,
      pendingPayments,
      verifiedPayments,
      rejectedPayments,
      todayCollection,
      thisMonthCollection
    };
  }
};
